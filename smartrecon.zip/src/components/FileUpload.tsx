import React, { useState } from "react";
import { Upload, FileText, CheckCircle2, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Dataset } from "@/src/types";
import { toast } from "sonner";

interface FileUploadProps {
  label: string;
  onUpload: (dataset: Dataset) => void;
}

export function FileUpload({ label, onUpload }: FileUploadProps) {
  const [isUploading, setIsUploading] = useState(false);
  const [dataset, setDataset] = useState<Dataset | null>(null);

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Basic validation
    const ext = file.name.split('.').pop()?.toLowerCase();
    if (!['csv', 'xlsx', 'xls'].includes(ext || '')) {
      toast.error("Invalid file type. Please upload CSV or Excel.");
      return;
    }

    setIsUploading(true);
    const formData = new FormData();
    formData.append("file", file);

    try {
      const uploadUrl = "/api/upload";
      console.log(`Fetching: ${uploadUrl}`);
      
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 60000); // 60s timeout

      const response = await fetch(uploadUrl, {
        method: "POST",
        body: formData,
        signal: controller.signal
      });
      
      clearTimeout(timeoutId);
      
      console.log(`Response status: ${response.status} ${response.statusText}`);
      const contentType = response.headers.get("content-type");
      console.log(`Content-Type: ${contentType}`);
      if (!contentType || !contentType.includes("application/json")) {
        const text = await response.text();
        console.error("Non-JSON response received:", text.slice(0, 200));
        throw new Error("Server returned an invalid response (HTML). The backend might be restarting or misconfigured.");
      }

      const data = await response.json();
      
      if (!response.ok) {
        throw new Error(data.error || `Upload failed with status ${response.status}`);
      }

      const datasetWithName = { ...data, name: file.name };
      setDataset(datasetWithName);
      onUpload(datasetWithName);
      toast.success(`${label} uploaded successfully`);
    } catch (error) {
      console.error("Upload failed", error);
      let message = "Upload failed. Please try again.";
      if (error instanceof Error) {
        if (error.name === "AbortError") {
          message = "Upload timed out after 60 seconds. The file might be too large.";
        } else {
          message = error.message;
        }
      }
      toast.error(message);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <Card className="border-dashed border-2">
      <CardHeader>
        <CardTitle className="text-sm font-medium flex items-center gap-2">
          <FileText className="w-4 h-4" />
          {label}
        </CardTitle>
        <CardDescription>Upload CSV or Excel file</CardDescription>
      </CardHeader>
      <CardContent>
        <div className="flex flex-col items-center justify-center gap-4 py-4">
          {dataset ? (
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2 text-green-600">
                <CheckCircle2 className="w-8 h-8" />
                <span className="font-medium">File Uploaded: {dataset.headers.length} columns found</span>
              </div>
              <Button variant="ghost" size="sm" onClick={() => setDataset(null)} className="text-xs text-muted-foreground">
                Change File
              </Button>
            </div>
          ) : (
            <div className="relative">
              <input
                type="file"
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
                onChange={handleFileChange}
                accept=".csv,.xlsx,.xls"
                disabled={isUploading}
              />
              <Button variant="outline" className="gap-2" disabled={isUploading}>
                {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Upload className="w-4 h-4" />}
                {isUploading ? "Uploading..." : "Select File"}
              </Button>
            </div>
          )}
          {dataset && (
            <div className="w-full mt-4">
              <p className="text-xs text-muted-foreground mb-2">Preview (first 3 rows):</p>
              <div className="overflow-x-auto border rounded">
                <table className="w-full text-[10px]">
                  <thead>
                    <tr className="bg-muted">
                      {dataset.headers.slice(0, 4).map((h) => (
                        <th key={h} className="p-1 text-left">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {dataset.preview.slice(0, 3).map((row, i) => (
                      <tr key={i} className="border-t">
                        {dataset.headers.slice(0, 4).map((h) => (
                          <td key={h} className="p-1 truncate max-w-[100px]">{row[h]}</td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
