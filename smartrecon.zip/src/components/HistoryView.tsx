import React, { useEffect, useState } from "react";
import { 
  History, 
  Calendar, 
  FileText, 
  ArrowRight, 
  Trash2, 
  Download,
  Search,
  Filter,
  ArrowRightLeft
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { HistoryItem } from "@/src/types";
import { toast } from "sonner";
import { format } from "date-fns";
import { collection, query, where, orderBy, onSnapshot, deleteDoc, doc } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { useAuth } from "@/src/components/FirebaseProvider";

export function HistoryView() {
  const { user } = useAuth();
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState("");

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "reconciliations"),
      where("userId", "==", user.uid),
      orderBy("timestamp", "desc")
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const items = snapshot.docs.map(doc => {
        const data = doc.data();
        return {
          ...data,
          id: doc.id,
          timestamp: data.timestamp?.toDate().toISOString() || new Date().toISOString()
        } as HistoryItem;
      });
      setHistory(items);
      setIsLoading(false);
    }, (error) => {
      console.error("Failed to fetch history", error);
      toast.error("Could not load reconciliation history");
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleDelete = async (id: string) => {
    try {
      await deleteDoc(doc(db, "reconciliations", id));
      toast.success("History record deleted");
    } catch (err) {
      toast.error("Failed to delete record");
    }
  };

  const filteredHistory = history.filter(h => 
    h.datasetAName.toLowerCase().includes(searchTerm.toLowerCase()) ||
    h.datasetBName.toLowerCase().includes(searchTerm.toLowerCase())
  );

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <History className="w-12 h-12 text-gray-300 animate-pulse mb-4" />
        <p className="text-gray-500">Loading audit trails...</p>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-gray-900">Audit History</h2>
          <p className="text-gray-500 mt-1">Review and manage your previous reconciliation batches.</p>
        </div>
        <div className="relative w-full md:w-72">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <Input 
            placeholder="Search batches..." 
            className="pl-10"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
      </div>

      {filteredHistory.length === 0 ? (
        <Card className="border-dashed border-2 py-20">
          <CardContent className="flex flex-col items-center justify-center text-center">
            <div className="p-4 bg-gray-50 rounded-full mb-4">
              <ArrowRightLeft className="w-12 h-12 text-gray-300" />
            </div>
            <h3 className="text-lg font-semibold text-gray-900">No History Found</h3>
            <p className="text-gray-500 max-w-sm mt-2">
              {searchTerm ? "No batches match your search criteria." : "Your archived reconciliation batches will appear here for audit purposes."}
            </p>
            {!searchTerm && (
              <Button variant="outline" className="mt-6" onClick={() => window.location.reload()}>
                Refresh History
              </Button>
            )}
          </CardContent>
        </Card>
      ) : (
        <div className="grid grid-cols-1 gap-4">
          {filteredHistory.map((item) => (
            <Card key={item.id} className="group hover:border-blue-200 transition-all overflow-hidden">
              <CardContent className="p-0">
                <div className="flex flex-col md:flex-row md:items-stretch">
                  <div className="p-6 flex-1 space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2 text-xs font-medium text-gray-400 uppercase tracking-widest">
                        <Calendar className="w-3 h-3" />
                        {format(new Date(item.timestamp), "MMM d, yyyy • HH:mm")}
                      </div>
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-100">
                        {item.summary.matchedPercent}% Match
                      </Badge>
                    </div>

                    <div className="flex items-center gap-4">
                      <div className="flex-1">
                        <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">Source A</p>
                        <p className="text-sm font-semibold text-gray-900 truncate">{item.datasetAName}</p>
                      </div>
                      <ArrowRight className="w-4 h-4 text-gray-300" />
                      <div className="flex-1">
                        <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">Source B</p>
                        <p className="text-sm font-semibold text-gray-900 truncate">{item.datasetBName}</p>
                      </div>
                    </div>

                    <div className="grid grid-cols-4 gap-4 pt-2">
                      <div>
                        <p className="text-[10px] text-gray-400 uppercase">Matched</p>
                        <p className="text-sm font-bold text-green-600">{item.summary.matched}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 uppercase">Mismatch</p>
                        <p className="text-sm font-bold text-amber-600">{item.summary.mismatches}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 uppercase">Unmatched</p>
                        <p className="text-sm font-bold text-red-600">{item.summary.unmatchedA + item.summary.unmatchedB}</p>
                      </div>
                      <div>
                        <p className="text-[10px] text-gray-400 uppercase">Variance</p>
                        <p className="text-sm font-bold text-blue-600">${item.summary.variance}</p>
                      </div>
                    </div>
                  </div>

                  <div className="bg-gray-50/50 p-4 flex md:flex-col justify-center gap-2 border-t md:border-t-0 md:border-l">
                    <Button variant="ghost" size="icon" className="text-gray-400 hover:text-blue-600">
                      <Download className="w-4 h-4" />
                    </Button>
                    <Button 
                      variant="ghost" 
                      size="icon" 
                      className="text-gray-400 hover:text-red-600"
                      onClick={() => handleDelete(item.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
