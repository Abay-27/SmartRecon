import React, { useEffect, useState } from "react";
import { 
  TrendingUp, 
  AlertTriangle, 
  ShieldAlert, 
  Trash2, 
  RefreshCcw,
  BarChart3,
  Activity,
  ShieldCheck,
  ArrowLeft
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  LineChart,
  Line,
  Cell
} from "recharts";
import { collection, query, where, getDocs, deleteDoc, doc, writeBatch, orderBy, limit, onSnapshot } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { useAuth } from "@/src/components/FirebaseProvider";
import { toast } from "sonner";
import { motion } from "motion/react";
import { format } from "date-fns";

export function ReportsDashboard({ onBack }: { onBack: () => void }) {
  const { user, profile } = useAuth();
  const [stats, setStats] = useState({
    totalBatches: 0,
    avgMatchRate: 0,
    totalVariance: 0,
    totalAnomalies: 0,
    history: [] as any[],
    recentAnomalies: [] as any[],
  });

  const [isLoading, setIsLoading] = useState(true);
  const [isClearing, setIsClearing] = useState(false);

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, "reconciliations"),
      where("userId", "==", user.uid),
      orderBy("timestamp", "desc"),
      limit(20)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const docs = snapshot.docs.map(d => ({ 
        ...d.data(), 
        id: d.id,
        date: d.data().timestamp?.toDate() 
      }));
      
      if (docs.length > 0) {
        const totalBatches = docs.length;
        const sumMatchRate = docs.reduce((acc, curr: any) => acc + (curr.summary?.matchedPercent || 0), 0);
        const totalVariance = docs.reduce((acc, curr: any) => acc + (curr.summary?.variance || 0), 0);
        const totalAnomalies = docs.reduce((acc, curr: any) => acc + (curr.summary?.anomaliesA || 0) + (curr.summary?.anomaliesB || 0), 0);

        // Collect all anomalies from recent docs for detailed view
        const allRecentAnomalies: any[] = [];
        docs.slice(0, 5).forEach((d: any) => {
          if (d.anomaliesA) allRecentAnomalies.push(...d.anomaliesA.map((a: any) => ({ ...a, batchId: d.id, batchDate: d.date })));
          if (d.anomaliesB) allRecentAnomalies.push(...d.anomaliesB.map((a: any) => ({ ...a, batchId: d.id, batchDate: d.date })));
        });

        // Prepare chart data (reverse for chronological order)
        const historyData = [...docs].reverse().map((d: any) => ({
          name: format(d.date || new Date(), "MMM d"),
          matches: d.summary?.matched || 0,
          anomalies: (d.summary?.anomaliesA || 0) + (d.summary?.anomaliesB || 0),
          rate: parseFloat(d.summary?.matchedPercent || 0)
        }));

        setStats({
          totalBatches,
          avgMatchRate: parseFloat((sumMatchRate / totalBatches).toFixed(1)),
          totalVariance,
          totalAnomalies,
          history: historyData,
          recentAnomalies: allRecentAnomalies.sort((a, b) => (b.riskScore || 0) - (a.riskScore || 0)).slice(0, 5),
          totalSystemCount: profile?.reconciliationCount || 0
        });
      } else {
        setStats({
          totalBatches: 0,
          avgMatchRate: 0,
          totalVariance: 0,
          totalAnomalies: 0,
          history: [],
          recentAnomalies: [],
          totalSystemCount: profile?.reconciliationCount || 0
        });
      }
      setIsLoading(false);
    }, (err) => {
      console.error("Reports fetch error:", err);
      toast.error("Failed to load analytics");
      setIsLoading(false);
    });

    return () => unsubscribe();
  }, [user]);

  const handleClearAnalytics = async () => {
    if (!user) return;
    if (!confirm("Are you sure you want to remove all reconciliation analytics? This will clear your history dashboard as well.")) return;

    setIsClearing(true);
    try {
      const q = query(collection(db, "reconciliations"), where("userId", "==", user.uid));
      const snapshot = await getDocs(q);
      
      const batch = writeBatch(db);
      snapshot.docs.forEach((d) => {
        batch.delete(d.ref);
      });
      
      await batch.commit();
      toast.success("Analytics dashboard cleared successfully");
    } catch (error) {
      console.error("Clear failed:", error);
      toast.error("Failed to clear analytics");
    } finally {
      setIsClearing(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex flex-col items-center justify-center py-20 space-y-4">
        <RefreshCcw className="w-10 h-10 text-blue-500 animate-spin" />
        <p className="text-gray-500 font-medium">Crunching your numbers...</p>
      </div>
    );
  }

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold tracking-tight text-gray-900">Interactive Analytics</h2>
          <p className="text-gray-500">Real-time performance tracking based on your processed batches.</p>
        </div>
        <div className="flex items-center gap-2">
          <Button variant="outline" onClick={onBack} className="gap-2">
            <ArrowLeft className="w-4 h-4" />
            Back
          </Button>
          <Button 
            variant="ghost" 
            onClick={handleClearAnalytics} 
            className="gap-2 text-red-500 hover:text-red-600 hover:bg-red-50"
            disabled={isClearing || stats.totalBatches === 0}
          >
            <Trash2 className="w-4 h-4" />
            Clear Data
          </Button>
        </div>
      </div>

      {stats.totalBatches === 0 ? (
        <Card className="border-dashed border-2 py-20 text-center bg-gray-50/50">
          <CardContent className="space-y-4">
            <div className="w-16 h-16 bg-white rounded-full flex items-center justify-center mx-auto shadow-sm border">
              <BarChart3 className="w-8 h-8 text-gray-300" />
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold text-gray-900">No Analytics Yet</h3>
              <p className="text-gray-500 max-w-sm mx-auto">Perform and archive your first reconciliation to see real-time performance metrics here.</p>
            </div>
            <Button onClick={onBack} className="bg-blue-600">Reconcile Now</Button>
          </CardContent>
        </Card>
      ) : (
        <>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <StatCard 
              label="Total Batches" 
              value={stats.totalBatches} 
              icon={<Activity className="text-blue-500" />} 
              trend="+1 session"
            />
            <StatCard 
              label="System Counter" 
              value={profile?.reconciliationCount || 0} 
              icon={<ShieldCheck className="text-purple-500" />} 
              trend="Total Runs"
            />
            <StatCard 
              label="Avg Match Rate" 
              value={`${stats.avgMatchRate}%`} 
              icon={<TrendingUp className="text-green-500" />} 
              trend="Accuracy"
            />
            <StatCard 
              label="Total Variance" 
              value={`$${stats.totalVariance.toLocaleString()}`} 
              icon={<AlertTriangle className="text-amber-500" />} 
              trend="Variance"
            />
            <StatCard 
              label="Risks Flagged" 
              value={stats.totalAnomalies} 
              icon={<ShieldAlert className="text-red-500" />} 
              trend="Anomalies"
            />
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-1 p-6 border-none shadow-sm bg-white">
              <CardHeader className="p-0 mb-6">
                <CardTitle className="text-lg font-bold flex items-center gap-2">
                  <ShieldAlert className="w-5 h-5 text-red-500" />
                  High-Risk Anomaly Feed
                </CardTitle>
                <CardDescription>Top suspicious records flagged by AI scoring</CardDescription>
              </CardHeader>
              <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2 custom-scrollbar">
                {stats.recentAnomalies.length > 0 ? (
                  stats.recentAnomalies.map((anom, i) => (
                    <div key={anom.id || i} className="p-3 bg-red-50/50 rounded-xl border border-red-100 flex items-start gap-3 hover:bg-red-50 transition-colors">
                      <div className="w-8 h-8 rounded-lg bg-red-100 flex items-center justify-center shrink-0 shadow-sm">
                        <AlertTriangle className="w-4 h-4 text-red-600" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-start mb-1">
                          <p className="text-xs font-bold text-gray-900 truncate uppercase">{anom.customer || "Unknown Entity"}</p>
                          <Badge variant="destructive" className="h-4 text-[8px] uppercase px-1">
                            {anom.severity}
                          </Badge>
                        </div>
                        <p className="text-sm font-mono font-bold text-red-700">${anom.amount?.toLocaleString()}</p>
                        <div className="mt-2 space-y-1">
                          {anom.reasons?.slice(0, 2).map((r: string, idx: number) => (
                            <p key={idx} className="text-[9px] text-red-600/70 leading-tight flex gap-1 items-start">
                              <span className="shrink-0">•</span> {r}
                            </p>
                          ))}
                        </div>
                        <div className="mt-2 flex items-center justify-between">
                          <span className="text-[8px] text-gray-400">{format(new Date(anom.batchDate || Date.now()), "MMM d, HH:mm")}</span>
                          <span className="text-[8px] font-bold text-red-400 bg-red-50 px-1 rounded">Score: {Math.round((anom.riskScore || 0) * 100)}%</span>
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="h-full flex flex-col items-center justify-center py-20 opacity-50 space-y-2">
                    <ShieldAlert className="w-8 h-8 text-slate-300" />
                    <p className="text-xs text-slate-400">No high-risk anomalies detected in recent batches</p>
                  </div>
                )}
              </div>
            </Card>

            <div className="lg:col-span-2 space-y-6">
              <Card className="p-6 border-none shadow-sm bg-white">
                <CardHeader className="p-0 mb-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg font-bold">Matching vs. Anomalies</CardTitle>
                      <CardDescription>Correlation between matched volume and flagged risks</CardDescription>
                    </div>
                  </div>
                </CardHeader>
                <div className="h-72">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.history}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                      <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
                      <YAxis fontSize={10} axisLine={false} tickLine={false} />
                      <Tooltip 
                        cursor={{fill: '#f8fafc'}}
                        contentStyle={{borderRadius: '12px', border: 'none', boxShadow: '0 10px 15px -3px rgb(0 0 0 / 0.1)'}}
                      />
                      <Bar dataKey="matches" fill="#2563eb" radius={[4, 4, 0, 0]} barSize={20} />
                      <Bar dataKey="anomalies" fill="#ef4444" radius={[4, 4, 0, 0]} barSize={20} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                 <Card className="p-6 border-none shadow-sm bg-white">
                  <CardHeader className="p-0 mb-6">
                    <CardTitle className="text-sm font-bold">Accuracy Index (%)</CardTitle>
                  </CardHeader>
                  <div className="h-40">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={stats.history}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis hide dataKey="name" />
                        <YAxis hide domain={[0, 100]} />
                        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', padding: '4px 8px'}} />
                        <Line 
                          type="monotone" 
                          dataKey="rate" 
                          stroke="#10b981" 
                          strokeWidth={2} 
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </Card>

                <Card className="p-6 border-none shadow-sm bg-white">
                  <CardHeader className="p-0 mb-6">
                    <CardTitle className="text-sm font-bold">Anomaly Intensity</CardTitle>
                  </CardHeader>
                  <div className="h-40">
                    <ResponsiveContainer width="100%" height="100%">
                      <LineChart data={stats.history}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f0f0f0" />
                        <XAxis hide dataKey="name" />
                        <YAxis hide />
                        <Tooltip contentStyle={{borderRadius: '12px', border: 'none', padding: '4px 8px'}} />
                        <Line 
                          type="monotone" 
                          dataKey="anomalies" 
                          stroke="#ef4444" 
                          strokeWidth={2} 
                          dot={false}
                        />
                      </LineChart>
                    </ResponsiveContainer>
                  </div>
                </Card>
              </div>
            </div>
          </div>
        </>
      )}
    </div>
  );
}

function StatCard({ label, value, icon, trend }: any) {
  return (
    <Card className="overflow-hidden border-none shadow-sm bg-white group hover:shadow-md transition-all">
      <CardContent className="p-6">
        <div className="flex justify-between items-start">
          <div className="space-y-3">
            <div className="p-2 w-fit bg-gray-50 rounded-lg group-hover:bg-blue-50 transition-colors">
              {React.cloneElement(icon, { size: 18 })}
            </div>
            <div>
              <p className="text-[10px] font-bold text-gray-400 uppercase tracking-widest">{label}</p>
              <h3 className="text-2xl font-bold text-gray-900 mt-1">{value}</h3>
            </div>
          </div>
          <Badge variant="outline" className="bg-gray-50 border-gray-100 text-[9px] h-5 px-1.5 font-medium">
            {trend}
          </Badge>
        </div>
      </CardContent>
    </Card>
  );
}
