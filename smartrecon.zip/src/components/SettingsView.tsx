import React, { useEffect, useState } from "react";
import { 
  Settings, 
  Shield, 
  ShieldCheck,
  Bell, 
  Database, 
  Cpu, 
  Save,
  UserPlus,
  Lock,
  Trash2,
  Mail,
  UserCircle,
  Activity,
  CreditCard,
  Sparkles,
  Check,
  Zap,
  History,
  Smartphone,
  Building2,
  Copy,
  ExternalLink,
  Search,
  Upload,
  MoreVertical,
  CheckSquare,
  ShieldAlert
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Dialog, 
  DialogContent, 
  DialogDescription, 
  DialogFooter, 
  DialogHeader, 
  DialogTitle, 
  DialogTrigger 
} from "@/components/ui/dialog";
import { ReconciliationSettings } from "@/src/types";
import { toast } from "sonner";
import { useAuth } from "@/src/components/FirebaseProvider";
import { 
  doc, 
  updateDoc, 
  Timestamp, 
  collection, 
  query, 
  getDocs, 
  onSnapshot, 
  deleteDoc,
  setDoc,
  where
} from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { Badge } from "@/components/ui/badge";

interface User {
  id: string;
  name: string;
  email: string;
  role: string;
  status: string;
  accessStatus: 'pending' | 'approved' | 'blocked';
  reconciliationCount: number;
}

interface PaymentRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  transactionId: string;
  timestamp: any;
  status: 'pending' | 'approved' | 'rejected';
}

interface SettingsViewProps {
  settings: ReconciliationSettings;
  onSave: (settings: ReconciliationSettings) => void;
  defaultTab?: string;
}

export function SettingsView({ settings, onSave, defaultTab = "matching" }: SettingsViewProps) {
  const { profile, user } = useAuth();
  const [localSettings, setLocalSettings] = useState<ReconciliationSettings>(settings);
  const [users, setUsers] = useState<User[]>([]);
  const [paymentRequests, setPaymentRequests] = useState<PaymentRequest[]>([]);
  const [paymentSearch, setPaymentSearch] = useState("");
  const [isManualPaymentEntry, setIsManualPaymentEntry] = useState(false);
  const [manualPaymentData, setManualPaymentData] = useState({ email: "", transactionId: "", amount: 500 });
  const [isAddingUser, setIsAddingUser] = useState(false);
  const [newUser, setNewUser] = useState({ name: "", email: "", role: "Viewer" });
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [showManualPayment, setShowManualPayment] = useState(false);
  const [transactionId, setTransactionId] = useState("");
  const [activeTab, setActiveTab] = useState(defaultTab);
  const [selectedUserIds, setSelectedUserIds] = useState<Set<string>>(new Set());
  const [isBulkInviting, setIsBulkInviting] = useState(false);
  const bulkFileRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    setActiveTab(defaultTab);
  }, [defaultTab]);

  const handleManualPaymentConfirm = async () => {
    if (!transactionId) {
      toast.error("Please enter the transaction ID");
      return;
    }
    setIsProcessingPayment(true);
    try {
      const requestId = `pay-${Math.random().toString(36).substring(7)}`;
      await setDoc(doc(db, "payment_requests", requestId), {
        id: requestId,
        userId: user!.uid,
        userEmail: user!.email,
        userName: profile?.displayName || user!.displayName || "Unknown",
        transactionId: transactionId,
        timestamp: Timestamp.now(),
        status: "pending"
      });
      
      toast.success("Payment details submitted for verification. Your Pro account will be active once confirmed by an admin.");
      setShowManualPayment(false);
      setTransactionId("");
    } catch (error) {
      console.error("Payment submission failed:", error);
      toast.error("Failed to submit payment details");
    } finally {
      setIsProcessingPayment(false);
    }
  };

  const handleApprovePayment = async (request: PaymentRequest) => {
    try {
      // 1. Update user profile
      const userRef = doc(db, "users", request.userId);
      await updateDoc(userRef, {
        subscriptionStatus: "active",
        plan: "pro",
        expiresAt: Timestamp.fromDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000))
      });

      // 2. Update request status
      await updateDoc(doc(db, "payment_requests", request.id), {
        status: "approved"
      });

      toast.success(`Payment approved for ${request.userEmail}`);
    } catch (error) {
      console.error("Approval failed:", error);
      toast.error("Failed to approve payment");
    }
  };

  const handleApproveUser = async (userId: string) => {
    try {
      await updateDoc(doc(db, "users", userId), {
        accessStatus: "approved"
      });
      toast.success("User access approved");
    } catch (error) {
      toast.error("Failed to approve user");
    }
  };

  const handleBlockUser = async (userId: string) => {
    try {
      await updateDoc(doc(db, "users", userId), {
        accessStatus: "blocked"
      });
      toast.success("User blocked");
    } catch (error) {
      toast.error("Failed to block user");
    }
  };

  const handleRejectPayment = async (requestId: string) => {
    try {
      await updateDoc(doc(db, "payment_requests", requestId), {
        status: "rejected"
      });
      toast.success("Payment request rejected");
    } catch (error) {
      toast.error("Failed to reject payment");
    }
  };

  const handleUpdateUserRole = async (userId: string, newRole: string) => {
    try {
      await updateDoc(doc(db, "users", userId), {
        role: newRole.toLowerCase()
      });
      toast.success("User role updated");
    } catch (error) {
      toast.error("Failed to update role");
    }
  };

  const handleManualAdminPayment = async () => {
    if (!manualPaymentData.email || !manualPaymentData.transactionId) {
      toast.error("Please fill in all fields");
      return;
    }
    try {
      const usersRef = collection(db, "users");
      const q = query(usersRef, where("email", "==", manualPaymentData.email));
      const querySnapshot = await getDocs(q);
      
      if (querySnapshot.empty) {
        toast.error("User not found");
        return;
      }
      
      const userDoc = querySnapshot.docs[0];
      const userData = userDoc.data();
      
      await updateDoc(doc(db, "users", userDoc.id), {
        subscriptionStatus: "active",
        plan: "pro",
        expiresAt: Timestamp.fromDate(new Date(Date.now() + 30 * 24 * 60 * 60 * 1000))
      });
      
      const requestId = `admin-pay-${Math.random().toString(36).substring(7)}`;
      await setDoc(doc(db, "payment_requests", requestId), {
        id: requestId,
        userId: userDoc.id,
        userEmail: userData.email,
        userName: userData.displayName || "Unknown",
        transactionId: manualPaymentData.transactionId,
        amount: manualPaymentData.amount,
        timestamp: Timestamp.now(),
        status: "approved"
      });
      
      toast.success(`Pro access manually granted to ${manualPaymentData.email}`);
      setIsManualPaymentEntry(false);
      setManualPaymentData({ email: "", transactionId: "", amount: 500 });
    } catch (error) {
      console.error("Manual payment failed:", error);
      toast.error("Failed to process manual payment");
    }
  };

  useEffect(() => {
    if (!user || profile?.role !== 'admin') return;
    
    // Real-time users sync from Firestore - ONLY for admins
    const q = query(collection(db, "users"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const usersList: User[] = [];
      querySnapshot.forEach((doc) => {
        const data = doc.data();
        usersList.push({
          id: doc.id,
          name: data.displayName || data.name || "Unknown",
          email: data.email || "",
          role: data.role || "Viewer",
          status: data.subscriptionStatus === 'active' ? 'Active' : 'Inactive',
          accessStatus: data.accessStatus || 'approved',
          reconciliationCount: data.reconciliationCount || 0
        });
      });
      setUsers(usersList);
    }, (err) => {
      console.error("Failed to fetch users from Firestore:", err);
    });

    return () => unsubscribe();
  }, [user, profile?.role]);

  useEffect(() => {
    if (!user || profile?.role !== 'admin') return;

    const q = query(collection(db, "payment_requests"));
    const unsubscribe = onSnapshot(q, (querySnapshot) => {
      const requests: PaymentRequest[] = [];
      querySnapshot.forEach((doc) => {
        requests.push(doc.data() as PaymentRequest);
      });
      setPaymentRequests(requests.filter(r => r.status === 'pending'));
    }, (err) => {
      console.error("Failed to fetch payment requests:", err);
    });

    return () => unsubscribe();
  }, [user, profile?.role]);

  const handleAddUser = async () => {
    if (!newUser.name || !newUser.email) {
      toast.error("Please fill in all fields");
      return;
    }
    try {
      // In this simulation, we create a placeholder user document
      // In a real app, this would be an invitation flow
      const tempId = `user-${Math.random().toString(36).substring(7)}`;
      await setDoc(doc(db, "users", tempId), {
        uid: tempId,
        displayName: newUser.name,
        email: newUser.email,
        role: newUser.role.toLowerCase(),
        subscriptionStatus: 'inactive',
        plan: 'free',
        createdAt: Timestamp.now()
      });
      
      toast.success("User invited successfully");
      setIsAddingUser(false);
      setNewUser({ name: "", email: "", role: "Viewer" });
    } catch (err) {
      console.error("Failed to add user:", err);
      toast.error("Failed to add user to team");
    }
  };

  const handleDeleteUser = async (id: string) => {
    try {
      await deleteDoc(doc(db, "users", id));
      toast.success("User removed from team");
      setSelectedUserIds(prev => {
        const next = new Set(prev);
        next.delete(id);
        return next;
      });
    } catch (err) {
      console.error("Failed to remove user:", err);
      toast.error("Failed to remove user");
    }
  };

  const handleBulkInvite = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setIsBulkInviting(true);
    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const text = e.target?.result as string;
        const lines = text.split(/\r?\n/).filter(l => l.trim() !== "");
        
        let successCount = 0;
        let failCount = 0;

        // Skip header if it looks like one
        const startIndex = lines[0].toLowerCase().includes("email") ? 1 : 0;

        for (let i = startIndex; i < lines.length; i++) {
          const parts = lines[i].split(",").map(p => p.trim());
          const email = parts[0];
          const role = (parts[1] || "Viewer").toLowerCase();
          const name = parts[2] || email.split("@")[0];

          if (email && email.includes("@")) {
            const tempId = `user-${Math.random().toString(36).substring(7)}`;
            await setDoc(doc(db, "users", tempId), {
              uid: tempId,
              displayName: name,
              email: email,
              role: role,
              subscriptionStatus: 'inactive',
              plan: 'free',
              createdAt: Timestamp.now()
            });
            successCount++;
          } else {
            failCount++;
          }
        }

        toast.success(`Bulk invite complete: ${successCount} invited, ${failCount} skipped`);
        if (bulkFileRef.current) bulkFileRef.current.value = "";
      } catch (err) {
        console.error("Bulk invite failed:", err);
        toast.error("Failed to process bulk invite CSV");
      } finally {
        setIsBulkInviting(false);
      }
    };
    reader.readAsText(file);
  };

  const handleBulkDelete = async () => {
    if (selectedUserIds.size === 0) return;
    
    const confirmDelete = window.confirm(`Are you sure you want to delete ${selectedUserIds.size} users?`);
    if (!confirmDelete) return;

    const ids = Array.from(selectedUserIds);
    let successCount = 0;

    toast.promise(
      Promise.all(ids.map(async (id: string) => {
        await deleteDoc(doc(db, "users", id));
        successCount++;
      })),
      {
        loading: 'Deleting users...',
        success: () => {
          setSelectedUserIds(new Set());
          return `Successfully deleted ${successCount} users`;
        },
        error: 'Failed to delete some users'
      }
    );
  };

  const handleBulkRoleChange = async (newRole: string) => {
    if (selectedUserIds.size === 0) return;

    const ids = Array.from(selectedUserIds);
    let successCount = 0;

    toast.promise(
      Promise.all(ids.map(async (id: string) => {
        await updateDoc(doc(db, "users", id), {
          role: newRole.toLowerCase()
        });
        successCount++;
      })),
      {
        loading: 'Updating roles...',
        success: () => {
          return `Successfully updated role to ${newRole} for ${successCount} users`;
        },
        error: 'Failed to update some roles'
      }
    );
  };

  const toggleUserSelection = (userId: string) => {
    setSelectedUserIds(prev => {
      const next = new Set(prev);
      if (next.has(userId)) {
        next.delete(userId);
      } else {
        next.add(userId);
      }
      return next;
    });
  };

  const toggleSelectAll = () => {
    if (selectedUserIds.size === users.length) {
      setSelectedUserIds(new Set());
    } else {
      setSelectedUserIds(new Set(users.map(u => u.id)));
    }
  };

  const handleSave = () => {
    onSave(localSettings);
    toast.success("System settings updated");
  };

  return (
    <div className="space-y-8 pb-12">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h2 className="text-3xl font-bold tracking-tight text-gray-900">System Configuration</h2>
          <p className="text-gray-500 mt-1">Manage reconciliation engine parameters and security protocols.</p>
        </div>
        <div className="flex items-center gap-3">
          <Button variant="outline" onClick={() => setLocalSettings(settings)}>Reset</Button>
          <Button onClick={handleSave} className="gap-2 bg-blue-600 hover:bg-blue-700 shadow-lg shadow-blue-600/20">
            <Save className="w-4 h-4" />
            Apply Changes
          </Button>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="bg-gray-100 p-1 rounded-xl w-full lg:w-auto inline-flex">
          <TabsTrigger value="matching" className="gap-2 px-6 rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Cpu className="w-4 h-4" />
            Engine
          </TabsTrigger>
          <TabsTrigger value="permissions" className="gap-2 px-6 rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Shield className="w-4 h-4" />
            Access
            {profile?.role === 'admin' && users.filter(u => u.accessStatus === 'pending').length > 0 && (
              <Badge className="ml-1 bg-amber-500 text-white px-1.5 h-4 min-w-[16px] flex items-center justify-center border-none text-[10px]">
                {users.filter(u => u.accessStatus === 'pending').length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger value="notifications" className="gap-2 px-6 rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <Bell className="w-4 h-4" />
            Alerts
          </TabsTrigger>
          <TabsTrigger value="subscription" className="gap-2 px-6 rounded-lg data-[state=active]:bg-white data-[state=active]:shadow-sm">
            <CreditCard className="w-4 h-4" />
            Subscription
            {profile?.role === 'admin' && paymentRequests.length > 0 && (
              <Badge className="ml-1 bg-blue-600 text-white px-1.5 h-4 min-w-[16px] flex items-center justify-center border-none text-[10px]">
                {paymentRequests.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="subscription" className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-2">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card className="border-none shadow-sm bg-white">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <CreditCard className="w-5 h-5 text-blue-500" />
                  Subscription Plan
                </CardTitle>
                <CardDescription>Manage your commercial license and billing status.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="p-6 rounded-2xl bg-gradient-to-br from-blue-600 to-blue-700 text-white shadow-lg shadow-blue-200">
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-white/20 rounded-lg backdrop-blur-sm">
                        <Sparkles className="w-5 h-5 text-white" />
                      </div>
                      <p className="font-bold text-lg">
                        {profile?.plan === 'pro' ? 'SmartRecon Pro' : 'Free Tier'}
                      </p>
                    </div>
                    <Badge className="bg-white/20 text-white border-none backdrop-blur-sm">
                      {profile?.subscriptionStatus === 'active' ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                  <div className="space-y-1">
                    <p className="text-blue-100 text-xs uppercase tracking-widest font-bold">Status</p>
                    <p className="text-sm">
                      {profile?.subscriptionStatus === 'active' 
                        ? `Your subscription is active until ${profile.expiresAt?.toLocaleDateString()}` 
                        : 'Upgrade to unlock full reconciliation features and AI mapping.'}
                    </p>
                  </div>
                </div>

                {profile?.subscriptionStatus !== 'active' && (
                  <div className="p-4 rounded-xl border border-blue-100 bg-blue-50/30">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Activity className="w-4 h-4 text-blue-600" />
                      </div>
                      <div>
                        <p className="text-sm font-bold text-blue-900">Payment Verification</p>
                        <p className="text-xs text-blue-700">
                          Manual payments are typically verified within 2-4 hours.
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mt-2">
                      <div className="p-3 rounded-xl bg-white/50 border border-blue-100 flex items-center justify-between">
                        <div>
                          <p className="text-[10px] font-bold text-blue-500 uppercase">Telebirr</p>
                          <p className="text-sm font-mono font-bold text-gray-900">0911 22 33 44</p>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                          navigator.clipboard.writeText("0911223344");
                          toast.success("Telebirr number copied");
                        }}>
                          <Copy className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                      <div className="p-3 rounded-xl bg-white/50 border border-blue-100 flex items-center justify-between">
                        <div>
                          <p className="text-[10px] font-bold text-purple-500 uppercase">CBE Bank</p>
                          <p className="text-sm font-mono font-bold text-gray-900">1000 1234 5678 9</p>
                        </div>
                        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => {
                          navigator.clipboard.writeText("1000123456789");
                          toast.success("CBE account number copied");
                        }}>
                          <Copy className="w-3.5 h-3.5" />
                        </Button>
                      </div>
                    </div>
                  </div>
                )}

                {profile?.subscriptionStatus !== 'active' && (
                  <div className="space-y-6">
                    <div className="grid grid-cols-1 gap-3">
                      {[
                        "Unlimited Batch Reconciliations",
                        "AI-Powered Field Mapping Suggestions",
                        "Advanced Anomaly Detection Engine",
                        "Persistent Audit History & Cloud Storage",
                        "Multi-user Team Permissions"
                      ].map((feature, i) => (
                        <div key={i} className="flex items-center gap-3 text-sm text-gray-600">
                          <div className="w-5 h-5 rounded-full bg-green-50 flex items-center justify-center shrink-0">
                            <Check className="w-3 h-3 text-green-600" />
                          </div>
                          {feature}
                        </div>
                      ))}
                    </div>
                    
                    <div className="pt-4 space-y-4">
                      <div className="flex items-end gap-2">
                        <span className="text-4xl font-bold text-gray-900">500 ETB</span>
                        <span className="text-gray-500 mb-1">/ month</span>
                        <span className="text-xs text-gray-400 mb-1 ml-2">(approx. $3 USD)</span>
                      </div>
                      
                      <Button 
                        className="w-full bg-blue-600 hover:bg-blue-700 h-14 text-lg font-bold gap-3 shadow-xl shadow-blue-600/20"
                        onClick={() => setShowManualPayment(true)}
                        disabled={isProcessingPayment}
                      >
                        <Zap className="w-5 h-5 fill-current" />
                        Upgrade to Pro Now
                      </Button>

                      <Dialog open={showManualPayment} onOpenChange={setShowManualPayment}>
                        <DialogContent className="max-w-md">
                          <DialogHeader>
                            <DialogTitle>Complete Your Subscription</DialogTitle>
                            <DialogDescription>
                              Please transfer 500 ETB to one of the accounts below and enter the transaction ID.
                            </DialogDescription>
                          </DialogHeader>
                          
                          <div className="space-y-4 py-4">
                            <div className="p-4 rounded-xl border bg-blue-50/50 space-y-3">
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-blue-600 rounded-lg">
                                  <Smartphone className="w-4 h-4 text-white" />
                                </div>
                                 <div>
                                  <p className="text-xs font-bold text-blue-600 uppercase tracking-wider">Telebirr</p>
                                  <div className="flex items-center gap-2">
                                    <p className="text-sm font-bold text-gray-900">0911 22 33 44</p>
                                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => {
                                      navigator.clipboard.writeText("0911223344");
                                      toast.success("Telebirr number copied");
                                    }}>
                                      <Copy className="w-3 h-3" />
                                    </Button>
                                  </div>
                                </div>
                              </div>
                            </div>

                            <div className="p-4 rounded-xl border bg-gray-50/50 space-y-3">
                              <div className="flex items-center gap-3">
                                <div className="p-2 bg-purple-600 rounded-lg">
                                  <Building2 className="w-4 h-4 text-white" />
                                </div>
                                <div>
                                  <p className="text-xs font-bold text-purple-600 uppercase tracking-wider">CBE Bank Transfer</p>
                                  <div className="flex items-center gap-2">
                                    <p className="text-sm font-bold text-gray-900">1000 1234 5678 9</p>
                                    <Button variant="ghost" size="icon" className="h-6 w-6" onClick={() => {
                                      navigator.clipboard.writeText("1000123456789");
                                      toast.success("CBE account number copied");
                                    }}>
                                      <Copy className="w-3 h-3" />
                                    </Button>
                                  </div>
                                  <p className="text-[10px] text-gray-500">Name: SmartRecon Solutions PLC</p>
                                </div>
                              </div>
                            </div>

                            <div className="space-y-2">
                              <label className="text-sm font-medium">Transaction ID / Reference</label>
                              <Input 
                                placeholder="Enter transaction ID from SMS" 
                                value={transactionId}
                                onChange={(e) => setTransactionId(e.target.value)}
                                className="h-12"
                              />
                            </div>
                          </div>

                          <DialogFooter>
                            <Button variant="outline" onClick={() => setShowManualPayment(false)}>Cancel</Button>
                            <Button 
                              onClick={handleManualPaymentConfirm} 
                              className="bg-blue-600 hover:bg-blue-700 h-12 px-8"
                              disabled={isProcessingPayment}
                            >
                              {isProcessingPayment ? "Verifying..." : "Confirm Payment"}
                            </Button>
                          </DialogFooter>
                        </DialogContent>
                      </Dialog>

                      <p className="text-[10px] text-center text-gray-400 uppercase tracking-widest font-medium">
                        Manual Bank Transfer / Telebirr / Chapa
                      </p>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm bg-white overflow-hidden">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <History className="w-5 h-5 text-gray-400" />
                  Billing History
                </CardTitle>
                <CardDescription>Review your past payments and invoices.</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <div className="flex flex-col items-center justify-center py-20 text-center px-6">
                  <div className="w-16 h-16 bg-gray-50 rounded-full flex items-center justify-center mb-4">
                    <CreditCard className="w-8 h-8 text-gray-200" />
                  </div>
                  <h4 className="font-semibold text-gray-900">No invoices yet</h4>
                  <p className="text-sm text-gray-500 mt-1">Once you subscribe, your monthly invoices will appear here for download.</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="matching" className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-2">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2 border-none shadow-sm bg-white">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Activity className="w-5 h-5 text-blue-500" />
                  Matching Algorithms
                </CardTitle>
                <CardDescription>Configure the primary logic for identifying transaction pairs.</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="space-y-3">
                  <label className="text-xs font-bold uppercase tracking-wider text-gray-400">Primary Engine</label>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
                    {[
                      { id: "exact", label: "Exact Match", desc: "ID + Amount" }
                    ].map((alg) => (
                      <div 
                        key={alg.id}
                        onClick={() => setLocalSettings({...localSettings, algorithm: alg.id as any})}
                        className={`
                          p-4 rounded-xl border-2 cursor-pointer transition-all
                          ${localSettings.algorithm === alg.id 
                            ? 'border-blue-500 bg-blue-50/50' 
                            : 'border-gray-100 hover:border-gray-200 bg-gray-50/30'}
                        `}
                      >
                        <p className={`font-semibold text-sm ${localSettings.algorithm === alg.id ? 'text-blue-700' : 'text-gray-700'}`}>
                          {alg.label}
                        </p>
                        <p className="text-[10px] text-gray-500 mt-1">{alg.desc}</p>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-8 pt-4">
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold uppercase tracking-wider text-gray-400">Amount Tolerance</label>
                      <span className="text-sm font-mono font-bold text-blue-600">${localSettings.amountTolerance.toFixed(2)}</span>
                    </div>
                    <Input 
                      type="number" 
                      step="0.01"
                      value={localSettings.amountTolerance}
                      onChange={(e) => setLocalSettings({...localSettings, amountTolerance: parseFloat(e.target.value) || 0})}
                      className="bg-gray-50 border-none focus-visible:ring-blue-500"
                    />
                    <p className="text-[10px] text-gray-400 italic">Maximum variance allowed for partial matches.</p>
                  </div>
                  
                  <div className="space-y-4">
                    <div className="flex justify-between items-center">
                      <label className="text-xs font-bold uppercase tracking-wider text-gray-400">Date Tolerance</label>
                      <span className="text-sm font-mono font-bold text-blue-600">{localSettings.dateTolerance} Days</span>
                    </div>
                    <Input 
                      type="number" 
                      value={localSettings.dateTolerance}
                      onChange={(e) => setLocalSettings({...localSettings, dateTolerance: parseInt(e.target.value) || 0})}
                      className="bg-gray-50 border-none focus-visible:ring-blue-500"
                    />
                    <p className="text-[10px] text-gray-400 italic">Allowed window for transaction timing differences.</p>
                  </div>
                </div>

                <div className="space-y-4 pt-4">
                  <div className="flex justify-between items-center">
                    <label className="text-xs font-bold uppercase tracking-wider text-gray-400">Similarity Threshold</label>
                    <span className="text-sm font-mono font-bold text-blue-600">{Math.round(localSettings.nameSimilarityThreshold * 100)}%</span>
                  </div>
                  <input 
                    type="range" 
                    min="0" 
                    max="1" 
                    step="0.01"
                    value={localSettings.nameSimilarityThreshold}
                    onChange={(e) => setLocalSettings({...localSettings, nameSimilarityThreshold: parseFloat(e.target.value)})}
                    className="w-full h-1.5 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-blue-600"
                  />
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm bg-white">
              <CardHeader>
                <CardTitle className="text-lg font-semibold flex items-center gap-2">
                  <Database className="w-5 h-5 text-purple-500" />
                  Data Policies
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 rounded-xl bg-gray-50 space-y-3">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-700">Auto-Archive</p>
                    <input 
                      type="checkbox" 
                      checked={localSettings.autoArchive}
                      onChange={(e) => setLocalSettings({...localSettings, autoArchive: e.target.checked})}
                      className="w-5 h-5 text-blue-600 rounded-lg border-gray-300 focus:ring-blue-500"
                    />
                  </div>
                  <p className="text-[10px] text-gray-500">Move completed batches to history automatically after 24 hours.</p>
                </div>

                <div className="p-4 rounded-xl bg-gray-50 space-y-3 opacity-50 cursor-not-allowed">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-700">Data Masking</p>
                    <input type="checkbox" disabled className="w-5 h-5 rounded-lg" />
                  </div>
                  <p className="text-[10px] text-gray-500">Mask PII data in reports (Enterprise Only).</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="permissions" className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-2">
          {profile?.role === 'admin' && (
            <div className="space-y-6">
              <Card className="border-none shadow-sm bg-white overflow-hidden">
                <CardHeader className="border-b bg-gray-50/50 py-4 flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg font-bold flex items-center gap-2">
                      <ShieldCheck className="w-5 h-5 text-amber-500" />
                      Pending Access Requests
                    </CardTitle>
                    <CardDescription>Approve or block new users.</CardDescription>
                  </div>
                  <Badge className="bg-amber-100 text-amber-700">
                    {users.filter(u => u.accessStatus === 'pending').length} Requests
                  </Badge>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="divide-y max-h-60 overflow-y-auto">
                    {users.filter(u => u.accessStatus === 'pending').map(user => (
                      <div key={user.id} className="p-4 flex items-center justify-between">
                        <div>
                          <p className="text-sm font-bold">{user.name}</p>
                          <p className="text-xs text-gray-500">{user.email} • {user.reconciliationCount} runs</p>
                        </div>
                        <div className="flex gap-2">
                          <Button size="sm" variant="outline" className="h-8" onClick={() => handleBlockUser(user.id)}>Block</Button>
                          <Button size="sm" className="h-8 bg-amber-500 hover:bg-amber-600 text-white" onClick={() => handleApproveUser(user.id)}>Approve</Button>
                        </div>
                      </div>
                    ))}
                    {users.filter(u => u.accessStatus === 'pending').length === 0 && (
                      <div className="p-8 text-center text-gray-400 text-sm">No pending requests</div>
                    )}
                  </div>
                </CardContent>
              </Card>

              <Card className="border-none shadow-sm bg-white overflow-hidden">
              <CardHeader className="flex flex-row items-center justify-between border-b bg-gray-50/50 py-4">
                <div>
                  <CardTitle className="text-lg font-bold flex items-center gap-2">
                    <CreditCard className="w-5 h-5 text-blue-600" />
                    Payment Verification
                  </CardTitle>
                  <CardDescription>
                    Verify transaction IDs and approve manual Pro upgrades.
                  </CardDescription>
                </div>
                <Dialog open={isManualPaymentEntry} onOpenChange={setIsManualPaymentEntry}>
                  <DialogTrigger render={
                    <Button variant="outline" size="sm" className="gap-2 border-blue-200 text-blue-700 hover:bg-blue-50">
                      <Zap className="w-4 h-4" />
                      Manual Activation
                    </Button>
                  } />
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Manual Pro Activation</DialogTitle>
                      <DialogDescription>
                        Directly grant Pro access by entering user email and payment reference.
                      </DialogDescription>
                    </DialogHeader>
                    <div className="space-y-4 py-4">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">User Email</label>
                        <Input 
                          placeholder="user@example.com" 
                          value={manualPaymentData.email}
                          onChange={(e) => setManualPaymentData({...manualPaymentData, email: e.target.value})}
                        />
                      </div>
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Transaction ID / Reference</label>
                        <Input 
                          placeholder="Enter payment reference" 
                          value={manualPaymentData.transactionId}
                          onChange={(e) => setManualPaymentData({...manualPaymentData, transactionId: e.target.value})}
                        />
                      </div>
                    </div>
                    <DialogFooter>
                      <Button variant="outline" onClick={() => setIsManualPaymentEntry(false)}>Cancel</Button>
                      <Button onClick={handleManualAdminPayment} className="bg-blue-600 hover:bg-blue-700">Confirm & Activate</Button>
                    </DialogFooter>
                  </DialogContent>
                </Dialog>
              </CardHeader>
              <CardContent className="p-6 space-y-6">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
                  <Input 
                    placeholder="Enter Transaction ID to verify..." 
                    className="pl-10 h-11 bg-gray-50 border-none focus-visible:ring-blue-500"
                    value={paymentSearch}
                    onChange={(e) => setPaymentSearch(e.target.value)}
                  />
                </div>

                <div className="space-y-3">
                  {paymentRequests
                    .filter(req => 
                      paymentSearch === "" || 
                      req.transactionId.toLowerCase().includes(paymentSearch.toLowerCase()) ||
                      req.userEmail.toLowerCase().includes(paymentSearch.toLowerCase())
                    )
                    .map((req) => (
                      <div key={req.id} className="flex items-center justify-between p-4 bg-white rounded-xl border hover:border-blue-200 transition-all shadow-sm group">
                        <div className="flex items-center gap-4">
                          <div className="w-10 h-10 rounded-full bg-blue-50 flex items-center justify-center font-bold text-blue-600 ring-2 ring-white">
                            {req.userName[0]}
                          </div>
                          <div>
                            <p className="text-sm font-bold text-gray-900">{req.userName}</p>
                            <p className="text-xs text-gray-500">{req.userEmail}</p>
                            <div className="flex items-center gap-2 mt-1">
                              <Badge variant="outline" className="text-[10px] font-mono border-blue-100 text-blue-700 bg-blue-50/50">
                                TX: {req.transactionId}
                              </Badge>
                              <span className="text-[10px] text-gray-400">
                                {new Date(req.timestamp?.toDate()).toLocaleString()}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                          <Button 
                            size="sm" 
                            variant="outline" 
                            className="text-red-600 border-red-100 hover:bg-red-50 h-9"
                            onClick={() => handleRejectPayment(req.id)}
                          >
                            Reject
                          </Button>
                          <Button 
                            size="sm" 
                            className="bg-green-600 hover:bg-green-700 h-9 shadow-sm"
                            onClick={() => handleApprovePayment(req)}
                          >
                            Approve Pro
                          </Button>
                        </div>
                      </div>
                    ))}
                  
                  {paymentRequests.length === 0 && (
                    <div className="text-center py-12 bg-gray-50 rounded-2xl border border-dashed border-gray-200">
                      <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center mx-auto mb-3 shadow-sm">
                        <Check className="w-6 h-6 text-gray-300" />
                      </div>
                      <p className="text-sm font-medium text-gray-500">All caught up!</p>
                      <p className="text-xs text-gray-400 mt-1">No pending payment requests to verify.</p>
                    </div>
                  )}

                  {paymentRequests.length > 0 && paymentRequests.filter(req => 
                    paymentSearch !== "" && 
                    (req.transactionId.toLowerCase().includes(paymentSearch.toLowerCase()) ||
                    req.userEmail.toLowerCase().includes(paymentSearch.toLowerCase()))
                  ).length === 0 && paymentSearch !== "" && (
                    <div className="text-center py-8">
                      <p className="text-sm text-gray-500">No requests found matching "{paymentSearch}"</p>
                    </div>
                  )}
                </div>
              </CardContent>
            </Card>

            <Card className="border-none shadow-sm bg-white overflow-hidden">
            <CardHeader className="flex flex-row items-center justify-between border-b bg-gray-50/50 py-4">
              <div>
                <CardTitle className="text-lg font-semibold">User Management</CardTitle>
                <CardDescription>Control access levels for team members.</CardDescription>
              </div>
              <div className="flex items-center gap-2">
                <input 
                  type="file" 
                  ref={bulkFileRef} 
                  onChange={handleBulkInvite} 
                  accept=".csv" 
                  className="hidden" 
                />
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="gap-2 border-dashed border-gray-300 text-gray-600 hover:border-blue-500 hover:text-blue-600"
                  onClick={() => bulkFileRef.current?.click()}
                  disabled={isBulkInviting}
                >
                  <Upload className="w-4 h-4" />
                  {isBulkInviting ? "Inviting..." : "Bulk Invite"}
                </Button>
                <Dialog open={isAddingUser} onOpenChange={setIsAddingUser}>
                  <DialogTrigger render={
                    <Button size="sm" className="gap-2 bg-blue-600 hover:bg-blue-700">
                      <UserPlus className="w-4 h-4" />
                      Invite User
                    </Button>
                  } />
                  <DialogContent>
                  <DialogHeader>
                    <DialogTitle>Add New User</DialogTitle>
                    <DialogDescription>Grant access to the reconciliation dashboard.</DialogDescription>
                  </DialogHeader>
                  <div className="space-y-4 py-4">
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Full Name</label>
                      <Input 
                        placeholder="John Doe" 
                        value={newUser.name}
                        onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">Email Address</label>
                      <Input 
                        type="email" 
                        placeholder="john@example.com" 
                        value={newUser.email}
                        onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                      />
                    </div>
                    <div className="space-y-2">
                      <label className="text-sm font-medium">System Role</label>
                      <Select 
                        value={newUser.role}
                        onValueChange={(v) => setNewUser({...newUser, role: v})}
                      >
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="Administrator">Administrator</SelectItem>
                          <SelectItem value="Auditor">Auditor</SelectItem>
                          <SelectItem value="Viewer">Viewer</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <DialogFooter>
                    <Button variant="outline" onClick={() => setIsAddingUser(false)}>Cancel</Button>
                    <Button onClick={handleAddUser} className="bg-blue-600 hover:bg-blue-700">Add User</Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
            <CardContent className="p-0">
              {selectedUserIds.size > 0 && (
                <div className="bg-blue-50 px-6 py-3 border-b border-blue-100 flex items-center justify-between animate-in fade-in slide-in-from-top-1">
                  <div className="flex items-center gap-3">
                    <CheckSquare className="w-4 h-4 text-blue-600" />
                    <span className="text-sm font-bold text-blue-900">{selectedUserIds.size} users selected</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Select onValueChange={handleBulkRoleChange}>
                      <SelectTrigger className="h-8 w-40 text-xs bg-white border-blue-200 text-blue-700">
                        <SelectValue placeholder="Change Role to..." />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Admin">Administrator</SelectItem>
                        <SelectItem value="Auditor">Auditor</SelectItem>
                        <SelectItem value="Viewer">Viewer</SelectItem>
                      </SelectContent>
                    </Select>
                    <Button 
                      variant="ghost" 
                      size="sm" 
                      className="text-red-600 hover:bg-red-100 h-8 gap-2"
                      onClick={handleBulkDelete}
                    >
                      <Trash2 className="w-4 h-4" />
                      Bulk Delete
                    </Button>
                  </div>
                </div>
              )}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="bg-gray-50/50 border-b">
                      <th className="px-6 py-3 w-10">
                        <input 
                          type="checkbox" 
                          className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                          checked={users.length > 0 && selectedUserIds.size === users.length}
                          onChange={toggleSelectAll}
                        />
                      </th>
                      <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-gray-400 italic">User Profile</th>
                      <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-gray-400 italic">Access Role</th>
                      <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-gray-400 italic">Status</th>
                      <th className="px-6 py-3 text-[10px] font-bold uppercase tracking-widest text-gray-400 italic text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y">
                    {users.map((user) => (
                      <tr key={user.id} className={`hover:bg-gray-50/80 transition-colors group ${selectedUserIds.has(user.id) ? 'bg-blue-50/30' : ''}`}>
                        <td className="px-6 py-4">
                          <input 
                            type="checkbox" 
                            className="w-4 h-4 rounded border-gray-300 text-blue-600 focus:ring-blue-500"
                            checked={selectedUserIds.has(user.id)}
                            onChange={() => toggleUserSelection(user.id)}
                          />
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-9 h-9 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center font-bold text-xs ring-2 ring-white">
                              {user.name.split(' ').map(n => n[0]).join('')}
                            </div>
                            <div>
                              <p className="text-sm font-semibold text-gray-900">{user.name}</p>
                              <p className="text-xs text-gray-500 font-mono">{user.email}</p>
                            </div>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <Select 
                            value={user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                            onValueChange={(v) => handleUpdateUserRole(user.id, v)}
                          >
                            <SelectTrigger className="h-8 w-32 text-xs">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Admin">Admin</SelectItem>
                              <SelectItem value="Auditor">Auditor</SelectItem>
                              <SelectItem value="Viewer">Viewer</SelectItem>
                            </SelectContent>
                          </Select>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1.5">
                            <div className={`w-1.5 h-1.5 rounded-full ${user.status === 'Active' ? 'bg-green-500' : 'bg-gray-300'}`} />
                            <span className={`text-[10px] font-bold uppercase tracking-tight ${user.status === 'Active' ? 'text-green-600' : 'text-gray-400'}`}>
                              {user.status}
                            </span>
                          </div>
                        </td>
                        <td className="px-6 py-4 text-right">
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="text-gray-400 hover:text-red-600 opacity-0 group-hover:opacity-100 transition-opacity"
                            onClick={() => handleDeleteUser(user.id)}
                          >
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>

          <Card className="border-none shadow-sm bg-white">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Lock className="w-5 h-5 text-orange-500" />
                Security & Compliance
              </CardTitle>
            </CardHeader>
            <CardContent className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="p-4 rounded-xl border bg-gray-50/50 space-y-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-orange-100 rounded-lg">
                    <Shield className="w-4 h-4 text-orange-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">Session Management</p>
                    <p className="text-[10px] text-gray-500">Auto-logout after period of inactivity.</p>
                  </div>
                </div>
                <Select defaultValue="30">
                  <SelectTrigger className="bg-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="15">15 Minutes</SelectItem>
                    <SelectItem value="30">30 Minutes</SelectItem>
                    <SelectItem value="60">1 Hour</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="p-4 rounded-xl border bg-gray-50/50 flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-blue-100 rounded-lg">
                    <Lock className="w-4 h-4 text-blue-600" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">2-Factor Auth</p>
                    <p className="text-[10px] text-gray-500">Require MFA for all administrators.</p>
                  </div>
                </div>
                <Button variant="outline" size="sm" className="bg-white">Enable</Button>
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {profile?.role !== 'admin' && (
        <div className="flex flex-col items-center justify-center py-20 text-center">
          <div className="w-20 h-20 bg-gray-50 rounded-full flex items-center justify-center mb-6">
            <ShieldAlert className="w-10 h-10 text-gray-300" />
          </div>
          <h3 className="text-xl font-bold text-gray-900">Privileged Access Only</h3>
          <p className="text-gray-500 max-w-sm mt-2">
            The Access and Permissions panel is restricted to system administrators.
          </p>
          <div className="mt-6 p-4 rounded-xl border bg-blue-50 max-w-md text-left">
            <p className="text-xs font-bold text-blue-600 uppercase tracking-widest mb-2">Request Access</p>
            <p className="text-sm text-blue-800">
              Only authorized administrators like <span className="font-bold">abaygebeyaw1996@gmail.com</span> can grant system permissions.
            </p>
          </div>
        </div>
      )}
    </TabsContent>

        <TabsContent value="notifications" className="mt-8 space-y-6 animate-in fade-in slide-in-from-bottom-2">
          <Card className="border-none shadow-sm bg-white">
            <CardHeader>
              <CardTitle className="text-lg font-semibold flex items-center gap-2">
                <Bell className="w-5 h-5 text-yellow-500" />
                Alert Channels
              </CardTitle>
              <CardDescription>Configure how the system communicates critical events.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { label: "Email Summaries", desc: "Daily reconciliation performance reports.", icon: <Mail className="w-4 h-4" />, checked: localSettings.notifications, key: 'notifications' },
                { label: "Anomaly Alerts", desc: "Instant notification for high-severity risks.", icon: <Activity className="w-4 h-4" />, checked: true },
                { label: "System Status", desc: "Alerts regarding server health and uptime.", icon: <Database className="w-4 h-4" />, checked: false }
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-4 rounded-xl border hover:border-blue-200 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="p-2 bg-gray-100 rounded-lg text-gray-600">
                      {item.icon}
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-900">{item.label}</p>
                      <p className="text-xs text-gray-500">{item.desc}</p>
                    </div>
                  </div>
                  <input 
                    type="checkbox" 
                    checked={item.checked}
                    onChange={(e) => item.key && setLocalSettings({...localSettings, [item.key]: e.target.checked})}
                    className="w-5 h-5 text-blue-600 rounded-lg border-gray-300 focus:ring-blue-500"
                  />
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
