import React from "react";
import { 
  BookOpen, 
  Upload, 
  Map, 
  Zap, 
  FileSearch, 
  Download, 
  AlertCircle, 
  Info, 
  CheckCircle2, 
  ArrowRight,
  ShieldCheck,
  Settings
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { motion } from "motion/react";

export function UserGuide() {
  const steps = [
    {
      title: "1. Data Acquisition",
      icon: <Upload className="w-6 h-6 text-blue-500" />,
      description: "Upload your primary system data (Source A) and your reporting file (Source B).",
      detailedGuide: [
        "Select your Core Banking CSV for Source A.",
        "Select your MFI or Excel statement for Source B.",
        "Wait for the green 'File Ready' confirmation."
      ],
      mockup: (
        <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-dashed border-slate-300 space-y-3">
          <div className="flex gap-2">
            <div className="flex-1 h-12 bg-white border rounded flex items-center px-4 gap-2 text-[10px] text-slate-400 font-mono">
              <Upload className="w-3 h-3" /> core_banking_2024.csv
            </div>
            <div className="w-8 h-12 bg-green-500 rounded flex items-center justify-center">
              <CheckCircle2 className="w-4 h-4 text-white" />
            </div>
          </div>
          <div className="flex gap-2 opacity-50">
            <div className="flex-1 h-12 bg-white border rounded flex items-center px-4 gap-2 text-[10px] text-slate-400 font-mono italic">
              <Upload className="w-3 h-3" /> Waiting for Source B...
            </div>
          </div>
        </div>
      ),
      tips: [
        "Ensure columns have clear headers",
        "Clean up any trailing spaces in IDs"
      ]
    },
    {
      title: "2. Intelligent Mapping",
      icon: <Map className="w-6 h-6 text-green-500" />,
      description: "Define which columns correspond to essential fields: Transaction ID, Amount, and Date.",
      detailedGuide: [
        "Match 'Txn_Ref' to 'Reference ID'.",
        "Match 'Debit_Amt' to 'Transaction Amount'.",
        "The AI will suggest matches based on header similarity."
      ],
      mockup: (
        <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200 space-y-2">
          <div className="flex items-center justify-between gap-4">
            <div className="w-24 h-6 bg-slate-200 rounded text-[10px] flex items-center px-2 font-bold">TXN_ID</div>
            <ArrowRight className="w-3 h-3 text-slate-400" />
            <div className="flex-1 h-6 bg-blue-100 text-blue-700 rounded text-[10px] flex items-center px-2 border border-blue-200">Reference_No</div>
          </div>
          <div className="flex items-center justify-between gap-4">
            <div className="w-24 h-6 bg-slate-200 rounded text-[10px] flex items-center px-2 font-bold">AMOUNT</div>
            <ArrowRight className="w-3 h-3 text-slate-400" />
            <div className="flex-1 h-6 bg-blue-100 text-blue-700 rounded text-[10px] flex items-center px-2 border border-blue-200">Value_USD</div>
          </div>
        </div>
      ),
      tips: [
        "Unique IDs provide the highest accuracy",
        "Source names don't need to match perfectly"
      ]
    },
    {
      title: "3. Reconciliation Rules",
      icon: <Settings className="w-6 h-6 text-amber-500" />,
      description: "Set tolerances for amounts and dates to handle timing differences.",
      detailedGuide: [
        "Adjust Amount Tolerance to handle rounding.",
        "Adjust Date Window for inter-bank delays.",
        "Choose matching algorithm: Exact or Fuzzy."
      ],
      mockup: (
        <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="space-y-4">
            <div className="space-y-1">
              <div className="flex justify-between text-[8px] font-bold uppercase text-slate-400">Amount Tolerance</div>
              <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 w-1/3" />
              </div>
              <div className="text-[10px] text-slate-600">$1.00 variance</div>
            </div>
            <div className="space-y-1">
              <div className="flex justify-between text-[8px] font-bold uppercase text-slate-400">Date Window</div>
              <div className="h-1 bg-slate-200 rounded-full overflow-hidden">
                <div className="h-full bg-blue-600 w-1/2" />
              </div>
              <div className="text-[10px] text-slate-600">2 Day(s)</div>
            </div>
          </div>
        </div>
      ),
      tips: [
        "Lower tolerances increase strictness",
        "Date windows account for bank holidays"
      ]
    },
    {
      title: "4. Result Analysis",
      icon: <FileSearch className="w-6 h-6 text-purple-500" />,
      description: "Review results categorized into Matched, Mismatches, and Anomalies.",
      detailedGuide: [
        "Filter results by 'Mismatch' to fix errors.",
        "Review 'Anomalies' for suspicious activity.",
        "Export the final report for audit compliance."
      ],
      mockup: (
        <div className="mt-4 p-4 bg-slate-50 rounded-xl border border-slate-200">
          <div className="grid grid-cols-2 gap-2 mb-3">
            <div className="bg-white p-2 rounded border border-slate-100 flex flex-col items-center">
              <span className="text-[8px] font-bold text-slate-400">Matches</span>
              <span className="text-sm font-bold text-green-600">94%</span>
            </div>
            <div className="bg-white p-2 rounded border border-slate-100 flex flex-col items-center">
              <span className="text-[8px] font-bold text-slate-400">Anomalies</span>
              <span className="text-sm font-bold text-red-600">12</span>
            </div>
          </div>
          <div className="h-10 bg-blue-600 rounded flex items-center justify-center text-white text-[10px] font-bold">
            <Download className="w-3 h-3 mr-1" /> Export Report
          </div>
        </div>
      ),
      tips: [
        "Check Anomalies for suspicious timing",
        "Review Mismatches for partial variances"
      ]
    }
  ];

  return (
    <div className="space-y-12 pb-20">
      {/* Hero Section */}
      <div className="bg-white rounded-3xl p-10 shadow-sm border relative overflow-hidden">
        <div className="relative z-10 max-w-2xl">
          <Badge className="bg-blue-100 text-blue-700 hover:bg-blue-100 border-none mb-4">Documentation</Badge>
          <h1 className="text-4xl font-bold text-slate-900 mb-4">SmartRecon Learning Center</h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            Welcome to the comprehensive guide for SmartRecon. Our system uses advanced algorithms 
            to help you reconcile millions of financial records in seconds. Follow this manual to 
            master the automation workflow.
          </p>
        </div>
        <div className="absolute right-0 top-0 w-1/3 h-full bg-blue-50/50 -skew-x-12 translate-x-20 hidden lg:block" />
        <BookOpen className="absolute right-10 bottom-10 w-32 h-32 text-blue-100/50 hidden lg:block" />
      </div>

      {/* Quick Start Workflow */}
      <div className="space-y-6 text-center max-w-3xl mx-auto">
        <h2 className="text-2xl font-bold text-slate-900">Standard Reconciliation Workflow</h2>
        <p className="text-slate-500">Master these four core stages to achieve 99% automated accuracy.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {steps.map((step, index) => (
          <motion.div
            key={index}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ delay: index * 0.1 }}
          >
            <div className="bg-white rounded-3xl border shadow-sm hover:shadow-md transition-all h-full flex flex-col overflow-hidden">
              <div className="p-8 pb-0">
                <div className="w-12 h-12 bg-slate-50 rounded-xl flex items-center justify-center mb-6 border border-slate-100">
                  {step.icon}
                </div>
                <h3 className="text-xl font-bold text-slate-900 mb-2">{step.title}</h3>
                <p className="text-slate-500 text-sm mb-6 leading-relaxed">{step.description}</p>
                
                <div className="space-y-4 mb-8">
                  <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Process Steps</p>
                  <div className="space-y-3">
                    {step.detailedGuide?.map((item, i) => (
                      <div key={i} className="flex gap-3 text-sm text-slate-600">
                        <div className="w-5 h-5 rounded-full bg-blue-50 text-blue-600 flex items-center justify-center text-[10px] font-bold shrink-0">
                          {i + 1}
                        </div>
                        {item}
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Visual Mockup "Screenshot" */}
              <div className="px-8 pb-8">
                <div className="bg-slate-100/50 rounded-2xl p-2 border border-slate-200/60 shadow-inner">
                  <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-sm">
                    <div className="h-4 bg-slate-50 border-b border-slate-100 px-3 flex items-center gap-1">
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                      <div className="w-1.5 h-1.5 rounded-full bg-slate-200" />
                    </div>
                    {step.mockup}
                  </div>
                </div>
              </div>
              
              <div className="mt-auto px-8 pb-8 space-y-3">
                <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Pro Tips</p>
                {step.tips.map((tip, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-500">
                    <CheckCircle2 className="w-3.5 h-3.5 text-green-500 mt-0.5 shrink-0" />
                    <span>{tip}</span>
                  </div>
                ))}
              </div>
            </div>
          </motion.div>
        ))}
      </div>

      {/* Key Concepts Section */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 pt-8">
        <div className="lg:col-span-2 space-y-8">
          <div className="bg-slate-900 text-white rounded-3xl p-10 overflow-hidden relative">
            <h3 className="text-2xl font-bold mb-6">User Manual: Advanced Features</h3>
            <div className="space-y-6 relative z-10">
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-blue-500/20 flex items-center justify-center shrink-0">
                  <ShieldCheck className="w-5 h-5 text-blue-400" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1">Anomaly Detection Engine</h4>
                  <p className="text-slate-400 text-sm">Automated monitoring for rapid-fire transactions, odd-hour activity (11PM-5AM), and statistical amount outliers (Z-Score &gt; 3.0).</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-purple-500/20 flex items-center justify-center shrink-0">
                  <Zap className="w-5 h-5 text-purple-400" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1">Fuzzy Logic Matching</h4>
                  <p className="text-slate-400 text-sm">When exact IDs aren't available, the system uses Levenshtein distance for names and proximity windows for dates to find best-fit matches.</p>
                </div>
              </div>
              <div className="flex gap-4">
                <div className="w-10 h-10 rounded-full bg-amber-500/20 flex items-center justify-center shrink-0">
                  <Download className="w-5 h-5 text-amber-400" />
                </div>
                <div>
                  <h4 className="font-bold text-lg mb-1">Audit-Ready Exports</h4>
                  <p className="text-slate-400 text-sm">Every reconciliation generates a multi-sheet Excel workbook with side-by-side source comparisons and summary analytics.</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-blue-600 rounded-3xl p-8 text-white flex flex-col justify-between">
          <div>
            <Info className="w-10 h-10 mb-6 opacity-80" />
            <h3 className="text-xl font-bold mb-4">Need More Help?</h3>
            <p className="text-blue-100 text-sm leading-relaxed mb-6">
              Our support team is available for Pro subscribers to assist with custom data formats and integration challenges.
            </p>
          </div>
          <div className="space-y-3">
            <Button className="w-full bg-white text-blue-600 hover:bg-blue-50 border-none">Contact Support</Button>
            <Button variant="ghost" className="w-full text-white hover:bg-white/10 border-white/20">Release Notes</Button>
          </div>
        </div>
      </div>

      {/* Troubleshooting */}
      <div className="bg-white rounded-3xl border shadow-sm p-10">
        <h3 className="text-2xl font-bold mb-8 flex items-center gap-3">
          <AlertCircle className="w-6 h-6 text-red-500" />
          Common Troubleshooting
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
          <div className="space-y-4">
            <h4 className="font-bold text-slate-800">"No Columns Found"</h4>
            <p className="text-slate-600 text-sm leading-relaxed">Ensure your file starts at Row 1 with header labels. Hidden rows or heavy formatting in Excel can sometimes confuse the parser. Use "Paste Values Only" if issues persist.</p>
          </div>
          <div className="space-y-4">
            <h4 className="font-bold text-slate-800">Low Match Sensitivity</h4>
            <p className="text-slate-600 text-sm leading-relaxed">If records aren't matching but look identical, check the Reconciliation Rules in Settings. An amount tolerance of $0.00 might miss small penny differences caused by rounding.</p>
          </div>
        </div>
      </div>
    </div>
  );
}
