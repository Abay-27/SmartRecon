import React from "react";
import { 
  CheckCircle2, 
  AlertTriangle, 
  XCircle, 
  Download, 
  ArrowLeft,
  PieChart as PieChartIcon,
  TrendingUp,
  ShieldAlert
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ReconciliationResult, Anomaly, ReconciliationSettings } from "@/src/types";
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip, Legend } from "recharts";
import { utils, writeFile } from "xlsx";
import { toast } from "sonner";
import { Archive } from "lucide-react";
import { collection, addDoc, Timestamp } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { useAuth } from "@/src/components/FirebaseProvider";

interface ResultsViewProps {
  result: ReconciliationResult;
  settings: ReconciliationSettings;
  datasetAName: string;
  datasetBName: string;
  onReset: () => void;
}

export function ResultsView({ result, settings, datasetAName, datasetBName, onReset }: ResultsViewProps) {
  const { user } = useAuth();
  const [isArchiving, setIsArchiving] = React.useState(false);

  if (!result || !result.summary) {
    return (
      <div className="flex flex-col items-center justify-center py-12 space-y-4">
        <AlertTriangle className="w-12 h-12 text-amber-500" />
        <h2 className="text-xl font-semibold">Invalid Results</h2>
        <p className="text-muted-foreground text-center max-w-md">
          The reconciliation results could not be processed. Please try running the reconciliation again.
        </p>
        <Button onClick={onReset}>Back to Upload</Button>
      </div>
    );
  }

  const { summary } = result;

  const chartData = [
    { name: "Matched", value: summary.matched, color: "#10b981" },
    { name: "Mismatches", value: summary.mismatches, color: "#f59e0b" },
    { name: "Unmatched", value: summary.unmatchedA + summary.unmatchedB, color: "#ef4444" },
    { name: "Anomalies", value: summary.anomaliesA + summary.anomaliesB, color: "#8b5cf6" },
  ];

  const allAnomalies = [
    ...result.anomaliesA.map(a => ({ ...a, source: 'Source A' })),
    ...result.anomaliesB.map(a => ({ ...a, source: 'Source B' }))
  ];

  const handleArchive = async () => {
    if (!user) {
      toast.error("You must be logged in to archive results");
      return;
    }
    setIsArchiving(true);
    try {
      await addDoc(collection(db, "reconciliations"), {
        userId: user.uid,
        timestamp: Timestamp.now(),
        summary: result.summary,
        settings,
        datasetAName,
        datasetBName,
        id: `batch-${Date.now()}`,
        anomaliesA: result.anomaliesA,
        anomaliesB: result.anomaliesB
      });
      
      toast.success("Reconciliation archived to cloud history");
      onReset();
    } catch (error) {
      console.error("Archive failed:", error);
      toast.error("Failed to archive result to cloud");
    } finally {
      setIsArchiving(false);
    }
  };

  const handleExport = () => {
    try {
      const wb = utils.book_new();
      
      // 1. Summary Sheet
      const summaryData = [
        ["SmartRecon Reconciliation Summary Report"],
        ["Generated At", new Date().toLocaleString()],
        [],
        ["Metric", "Value"],
        ["Match Rate", `${summary.matchedPercent}%`],
        ["Total Records Source A", summary.totalA],
        ["Total Records Source B", summary.totalB],
        ["Matched Records", summary.matched],
        ["Mismatches Found", summary.mismatches],
        ["Unmatched Source A", summary.unmatchedA],
        ["Unmatched Source B", summary.unmatchedB],
        ["Total Anomalies Detected", summary.anomaliesA + summary.anomaliesB],
        ["Total Variance Amount", `$${summary.variance}`]
      ];
      const wsSummary = utils.aoa_to_sheet(summaryData);
      utils.book_append_sheet(wb, wsSummary, "Summary");

      // 2. Matched Records
      if (result.matched.length > 0) {
        const matchedData = result.matched.map(m => {
          const row: any = {};
          // Prefix Source A keys
          Object.keys(m.sourceA).forEach(key => {
            row[`A_${key}`] = m.sourceA[key];
          });
          // Prefix Source B keys
          Object.keys(m.sourceB).forEach(key => {
            row[`B_${key}`] = m.sourceB[key];
          });
          row.Match_Type = m.type;
          return row;
        });
        const wsMatched = utils.json_to_sheet(matchedData);
        utils.book_append_sheet(wb, wsMatched, "Matched");
      }

      // 3. Mismatches
      if (result.mismatches.length > 0) {
        const mismatchData = result.mismatches.map(m => {
          const row: any = {};
          // Prefix Source A keys
          Object.keys(m.sourceA).forEach(key => {
            row[`A_${key}`] = m.sourceA[key];
          });
          // Prefix Source B keys
          Object.keys(m.sourceB).forEach(key => {
            row[`B_${key}`] = m.sourceB[key];
          });
          row.Amount_Diff = m.diff.amount;
          row.Date_Diff_Days = m.diff.date;
          row.Match_Type = m.type;
          return row;
        });
        const wsMismatches = utils.json_to_sheet(mismatchData);
        utils.book_append_sheet(wb, wsMismatches, "Mismatches");
      }

      // 4. Unmatched A
      if (result.unmatchedA.length > 0) {
        const wsUnmatchedA = utils.json_to_sheet(result.unmatchedA);
        utils.book_append_sheet(wb, wsUnmatchedA, "Unmatched Source A");
      }

      // 5. Unmatched B
      if (result.unmatchedB.length > 0) {
        const wsUnmatchedB = utils.json_to_sheet(result.unmatchedB);
        utils.book_append_sheet(wb, wsUnmatchedB, "Unmatched Source B");
      }

      // 6. Anomalies
      if (allAnomalies.length > 0) {
        const anomalyData = allAnomalies.map(a => ({
          Source: a.source,
          Severity: a.severity,
          Reasons: a.reasons.join(", "),
          ...a.record
        }));
        const wsAnomalies = utils.json_to_sheet(anomalyData);
        utils.book_append_sheet(wb, wsAnomalies, "Anomalies");
      }

      writeFile(wb, `SmartRecon_Report_${new Date().toISOString().split('T')[0]}.xlsx`);
      toast.success("Report exported successfully!");
    } catch (error) {
      console.error("Export failed:", error);
      toast.error("Failed to export report. Please try again.");
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <Button variant="ghost" onClick={onReset} className="gap-2">
          <ArrowLeft className="w-4 h-4" />
          New Reconciliation
        </Button>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            className="gap-2 text-blue-600 border-blue-200 hover:bg-blue-50" 
            onClick={handleArchive}
            disabled={isArchiving}
          >
            <Archive className="w-4 h-4" />
            {isArchiving ? "Archiving..." : "Archive Result"}
          </Button>
          <Button variant="outline" className="gap-2" onClick={handleExport}>
            <Download className="w-4 h-4" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard 
          title="Match Rate" 
          value={`${summary.matchedPercent}%`} 
          icon={<CheckCircle2 className="text-green-500" />} 
          subValue={`${summary.matched} records`}
        />
        <StatCard 
          title="Mismatches" 
          value={summary.mismatches} 
          icon={<AlertTriangle className="text-amber-500" />} 
          subValue="Partial matches found"
        />
        <StatCard 
          title="Anomalies" 
          value={summary.anomaliesA + summary.anomaliesB} 
          icon={<ShieldAlert className="text-purple-500" />} 
          subValue="Potential risks flagged"
        />
        <StatCard 
          title="Variance" 
          value={`$${summary.variance}`} 
          icon={<TrendingUp className="text-blue-500" />} 
          subValue="Total difference"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Chart */}
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <PieChartIcon className="w-4 h-4" />
              Reconciliation Health
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={chartData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {chartData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Details Tabs */}
        <Card className="lg:col-span-2">
          <CardContent className="p-0">
            <Tabs defaultValue="matched" className="w-full">
              <TabsList className="w-full justify-start rounded-none border-b bg-transparent h-12 px-4">
                <TabsTrigger value="matched" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
                  Matched ({result.matched.length})
                </TabsTrigger>
                <TabsTrigger value="mismatches" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
                  Mismatches ({result.mismatches.length})
                </TabsTrigger>
                <TabsTrigger value="anomalies" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
                  Anomalies ({allAnomalies.length})
                </TabsTrigger>
                <TabsTrigger value="unmatched" className="data-[state=active]:border-b-2 data-[state=active]:border-primary rounded-none">
                  Unmatched ({result.unmatchedA.length + result.unmatchedB.length})
                </TabsTrigger>
              </TabsList>
              
              <TabsContent value="matched" className="p-4">
                <ReconTable data={result.matched} type="matched" sourceAName={datasetAName} sourceBName={datasetBName} />
              </TabsContent>
              <TabsContent value="mismatches" className="p-4">
                <ReconTable data={result.mismatches} type="mismatch" sourceAName={datasetAName} sourceBName={datasetBName} />
              </TabsContent>
              <TabsContent value="anomalies" className="p-4">
                <AnomalyTable data={allAnomalies} />
              </TabsContent>
              <TabsContent value="unmatched" className="p-4">
                <ReconTable 
                  data={[...result.unmatchedA.map(d => ({...d, source: 'A'})), ...result.unmatchedB.map(d => ({...d, source: 'B'}))]} 
                  type="unmatched" 
                  sourceAName={datasetAName} 
                  sourceBName={datasetBName} 
                />
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ title, value, icon, subValue }: any) {
  return (
    <Card>
      <CardContent className="pt-6">
        <div className="flex justify-between items-start">
          <div>
            <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">{title}</p>
            <h3 className="text-2xl font-bold mt-1">{value}</h3>
            <p className="text-xs text-muted-foreground mt-1">{subValue}</p>
          </div>
          <div className="p-2 bg-muted rounded-lg">
            {icon}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function AnomalyTable({ data }: { data: any[] }) {
  if (data.length === 0) return <div className="py-8 text-center text-muted-foreground">No anomalies detected</div>;

  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead>Source</TableHead>
            <TableHead>Reason</TableHead>
            <TableHead>Severity</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {data.map((item, i) => (
            <TableRow key={i}>
              <TableCell className="text-xs font-medium">{item.source}</TableCell>
              <TableCell>
                <div className="space-y-1">
                  {item.reasons.map((r: string, idx: number) => (
                    <div key={idx} className="text-xs text-gray-600 flex items-center gap-1">
                      <AlertTriangle className="w-3 h-3 text-amber-500" />
                      {r}
                    </div>
                  ))}
                </div>
              </TableCell>
              <TableCell>
                <Badge variant={item.severity === 'high' ? 'destructive' : 'warning'} className="text-[10px] capitalize">
                  {item.severity}
                </Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function ReconTable({ data, type, sourceAName, sourceBName }: { 
  data: any[], 
  type: 'matched' | 'mismatch' | 'unmatched',
  sourceAName: string,
  sourceBName: string
}) {
  if (data.length === 0) return <div className="py-8 text-center text-muted-foreground">No records found</div>;

  const showAll = type === 'unmatched';
  const displayDataList = showAll ? data : data.slice(0, 10);

  return (
    <div className="rounded-md border overflow-hidden">
      <Table>
        <TableHeader>
          <TableRow className="bg-muted/50">
            <TableHead className="w-[100px]">ID</TableHead>
            <TableHead className="w-1/3">{sourceAName}</TableHead>
            <TableHead className="w-1/3">{sourceBName}</TableHead>
            <TableHead className="text-center">Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {displayDataList.map((item, i) => {
            const isMismatch = type === 'mismatch';
            const isUnmatched = type === 'unmatched';
            
            if (isUnmatched) {
              const id = item.transactionId || item.id || item.ID || "N/A";
              const amount = item.amount || item.Amount || 0;
              const details = item.customerName || item.Customer || "Unknown Customer";
              
              return (
                <TableRow key={i}>
                  <TableCell className="font-mono text-[10px]">{id}</TableCell>
                  <TableCell>
                    {item.source === 'A' ? (
                      <div className="text-[11px]">
                        <p className="font-medium text-gray-900">{details}</p>
                        <p className="text-blue-600 font-bold">${amount}</p>
                      </div>
                    ) : (
                      <span className="text-gray-300 text-[10px] italic">No matching record</span>
                    )}
                  </TableCell>
                  <TableCell>
                    {item.source === 'B' ? (
                      <div className="text-[11px]">
                        <p className="font-medium text-gray-900">{details}</p>
                        <p className="text-blue-600 font-bold">${amount}</p>
                      </div>
                    ) : (
                      <span className="text-gray-300 text-[10px] italic">No matching record</span>
                    )}
                  </TableCell>
                  <TableCell className="text-center">
                    <Badge variant="destructive" className="text-[9px] px-1 h-5">
                      unmatched
                    </Badge>
                  </TableCell>
                </TableRow>
              );
            }

            const idA = item.sourceA.transactionId || item.sourceA.id || item.sourceA.ID || "N/A";
            const amountA = item.sourceA.amount || item.sourceA.Amount || 0;
            const detailsA = item.sourceA.customerName || item.sourceA.Customer || "Unknown Customer";

            const amountB = item.sourceB.amount || item.sourceB.Amount || 0;
            const detailsB = item.sourceB.customerName || item.sourceB.Customer || "Unknown Customer";

            return (
              <TableRow key={i}>
                <TableCell className="font-mono text-[10px]">{idA}</TableCell>
                <TableCell>
                  <div className="text-[11px]">
                    <p className="font-medium text-gray-900">{detailsA}</p>
                    <p className="text-blue-600 font-bold">${amountA}</p>
                  </div>
                </TableCell>
                <TableCell>
                  <div className="text-[11px]">
                    <p className="font-medium text-gray-900">{detailsB}</p>
                    <p className="text-blue-600 font-bold">${amountB}</p>
                    {isMismatch && (
                      <div className="mt-1 flex gap-1 flex-wrap">
                        {item.diff.amount !== 0 && (
                          <Badge variant="outline" className="text-[9px] text-amber-600 border-amber-200 bg-amber-50 px-1 py-0 h-4">
                            Diff: ${item.diff.amount.toFixed(2)}
                          </Badge>
                        )}
                        {item.diff.date !== null && item.diff.date !== 0 && (
                          <Badge variant="outline" className="text-[9px] text-blue-600 border-blue-200 bg-blue-50 px-1 py-0 h-4">
                            {item.diff.date.toFixed(1)} days
                          </Badge>
                        )}
                      </div>
                    )}
                  </div>
                </TableCell>
                <TableCell className="text-center">
                  <Badge 
                    variant={type === 'matched' ? 'default' : 'warning'} 
                    className="text-[9px] px-1 h-5 capitalize"
                  >
                    {type}
                  </Badge>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
      {!showAll && data.length > 10 && (
        <div className="p-2 text-center text-[10px] text-muted-foreground border-t">
          Showing first 10 of {data.length} records
        </div>
      )}
    </div>
  );
}

