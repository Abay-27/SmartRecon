import React, { useState } from "react";
import { Sparkles, ArrowRightLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dataset } from "@/src/types";
import { GoogleGenAI } from "@google/genai";

interface MappingViewProps {
  datasetA: Dataset;
  datasetB: Dataset;
  onMappingComplete: (mapA: any, mapB: any) => void;
}

const TARGET_FIELDS = ["transactionId", "amount"];

export function MappingView({ datasetA, datasetB, onMappingComplete }: MappingViewProps) {
  const [mapA, setMapA] = useState<Record<string, string>>({});
  const [mapB, setMapB] = useState<Record<string, string>>({});
  const [isSuggesting, setIsSuggesting] = useState(false);

  const handleAutoMap = async () => {
    setIsSuggesting(true);
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });
      
      const getMapping = async (headers: string[]) => {
        const prompt = `Given these column headers from a financial report: ${headers.join(", ")}. 
        Suggest the best mapping to these target fields: ${TARGET_FIELDS.join(", ")}.
        Return only a JSON object where keys are target fields and values are the matching headers.
        If no good match, use null.`;

        const response = await ai.models.generateContent({
          model: "gemini-3-flash-preview",
          contents: prompt,
        });
        
        const text = response.text || "";
        const jsonMatch = text.match(/\{.*\}/s);
        return jsonMatch ? JSON.parse(jsonMatch[0]) : {};
      };

      const [suggestionA, suggestionB] = await Promise.all([
        getMapping(datasetA.headers),
        getMapping(datasetB.headers),
      ]);

      setMapA(suggestionA);
      setMapB(suggestionB);
    } catch (error) {
      console.error("Auto-mapping failed", error);
    } finally {
      setIsSuggesting(false);
    }
  };

  const isComplete = TARGET_FIELDS.every(f => mapA[f] && mapB[f]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold flex items-center gap-2">
          <ArrowRightLeft className="w-5 h-5" />
          Matching Parameter
        </h2>
        <Button onClick={handleAutoMap} variant="outline" className="gap-2" disabled={isSuggesting}>
          <Sparkles className="w-4 h-4 text-blue-500" />
          {isSuggesting ? "Analyzing..." : "AI Auto-Map"}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <MappingCard 
          title="Source A (Core Banking)" 
          headers={datasetA.headers} 
          mapping={mapA} 
          onChange={(field, val) => setMapA(prev => ({ ...prev, [field]: val }))} 
        />
        <MappingCard 
          title="Source B (MFI Report)" 
          headers={datasetB.headers} 
          mapping={mapB} 
          onChange={(field, val) => setMapB(prev => ({ ...prev, [field]: val }))} 
        />
      </div>

      <div className="flex justify-center pt-4">
        <Button 
          size="lg" 
          disabled={!isComplete} 
          onClick={() => onMappingComplete(mapA, mapB)}
          className="px-12"
        >
          Run Reconciliation
        </Button>
      </div>
    </div>
  );
}

function MappingCard({ title, headers, mapping, onChange }: { 
  title: string, 
  headers: string[], 
  mapping: any, 
  onChange: (f: string, v: string) => void 
}) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-sm">{title}</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {TARGET_FIELDS.map((field) => (
          <div key={field} className="flex flex-col gap-1.5">
            <label className="text-xs font-medium capitalize">
              {field.replace(/([A-Z])/g, ' $1').trim()}
            </label>
            <Select value={mapping[field] || ""} onValueChange={(val) => onChange(field, val)}>
              <SelectTrigger>
                <SelectValue placeholder="Select column..." />
              </SelectTrigger>
              <SelectContent>
                {headers.map((h) => (
                  <SelectItem key={h} value={h}>{h}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        ))}
      </CardContent>
    </Card>
  );
}
