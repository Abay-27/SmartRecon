import React, { createContext, useContext, useEffect, useState } from 'react';
import { 
  onAuthStateChanged, 
  User as FirebaseUser,
  signInWithPopup,
  GoogleAuthProvider,
  signOut
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  onSnapshot,
  updateDoc,
  serverTimestamp,
  Timestamp
} from 'firebase/firestore';
import { auth, db } from '../lib/firebase';
import { toast } from 'sonner';

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: {
    userId?: string | null;
    email?: string | null;
    emailVerified?: boolean | null;
    isAnonymous?: boolean | null;
  }
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: {
      userId: auth.currentUser?.uid,
      email: auth.currentUser?.email,
      emailVerified: auth.currentUser?.emailVerified,
      isAnonymous: auth.currentUser?.isAnonymous,
    },
    operationType,
    path
  };
  console.error('Firestore Error:', JSON.stringify(errInfo, null, 2));
  if (path !== 'test/connection') {
    toast.error(`Access Denied: ${operationType} on ${path}`);
  }
  return errInfo;
}

interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  subscriptionStatus: 'active' | 'inactive' | 'past_due';
  plan: 'free' | 'pro';
  expiresAt?: Date;
  role: 'admin' | 'user';
  accessStatus: 'pending' | 'approved' | 'blocked';
  reconciliationCount?: number;
}

interface AuthContextType {
  user: FirebaseUser | null;
  profile: UserProfile | null;
  loading: boolean;
  login: () => Promise<void>;
  logout: () => Promise<void>;
  isSubscribed: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export function FirebaseProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [isLoggingIn, setIsLoggingIn] = useState(false);

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;

    const unsubscribeAuth = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      
      // Cleanup previous profile listener if it exists
      if (unsubProfile) {
        unsubProfile();
        unsubProfile = null;
      }

      if (firebaseUser) {
        const userDocRef = doc(db, 'users', firebaseUser.uid);
        
        unsubProfile = onSnapshot(userDocRef, (docSnap) => {
          if (docSnap.exists()) {
            const data = docSnap.data();
            // Automatically upgrade specific user to admin
            const isTargetAdmin = data.email?.toLowerCase() === 'abaygebeyaw1996@gmail.com';
            
            setProfile({
              uid: data.uid,
              email: data.email,
              displayName: data.displayName || '',
              subscriptionStatus: data.subscriptionStatus || 'inactive',
              plan: data.plan || 'free',
              expiresAt: data.expiresAt?.toDate(),
              role: isTargetAdmin ? 'admin' : (data.role || 'user'),
              accessStatus: data.accessStatus || (isTargetAdmin ? 'approved' : (data.role === 'admin' ? 'approved' : 'pending')),
              reconciliationCount: data.reconciliationCount || 0
            });

            // If we detected the target admin but role isn't saved yet, sync it
            if (isTargetAdmin && data.role !== 'admin') {
              updateDoc(userDocRef, { role: 'admin', accessStatus: 'approved' });
            }
          } else {
            const isTargetAdmin = firebaseUser.email?.toLowerCase() === 'abaygebeyaw1996@gmail.com';
            const newProfile: any = {
              uid: firebaseUser.uid,
              email: firebaseUser.email || '',
              displayName: firebaseUser.displayName || '',
              subscriptionStatus: 'inactive',
              plan: 'free',
              role: isTargetAdmin ? 'admin' : 'user',
              accessStatus: isTargetAdmin ? 'approved' : 'pending',
              reconciliationCount: 0
            };
            setDoc(userDocRef, {
              ...newProfile,
              createdAt: Timestamp.now()
            });
            setProfile(newProfile);
          }
          setLoading(false);
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, `users/${firebaseUser.uid}`);
          setLoading(false);
        });
      } else {
        setProfile(null);
        setLoading(false);
      }
    });

    return () => {
      unsubscribeAuth();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const login = async () => {
    if (isLoggingIn) return;
    setIsLoggingIn(true);
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
      toast.success("Successfully logged in");
    } catch (error: any) {
      console.error("Login error:", error);
      if (error.code === 'auth/popup-blocked') {
        toast.error("Login popup was blocked by your browser. Please allow popups for this site.");
      } else if (error.code === 'auth/cancelled-popup-request') {
        // Ignore user cancellation
      } else {
        toast.error("Failed to login. Please try again.");
      }
    } finally {
      setIsLoggingIn(true); // Keep it true for a moment to prevent rapid clicks
      setTimeout(() => setIsLoggingIn(false), 1000);
    }
  };

  const logout = async () => {
    try {
      await signOut(auth);
      toast.success("Logged out");
    } catch (error) {
      toast.error("Failed to logout");
    }
  };

  const isSubscribed = profile?.subscriptionStatus === 'active' || profile?.role === 'admin';

  return (
    <AuthContext.Provider value={{ user, profile, loading, login, logout, isSubscribed }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within a FirebaseProvider');
  }
  return context;
};
