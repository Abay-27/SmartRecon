import React, { useState, useEffect } from "react";
import { 
  LayoutDashboard, 
  FileUp, 
  ArrowRightLeft, 
  BarChart3, 
  Settings, 
  ShieldCheck,
  Bell,
  Search,
  User,
  Wifi,
  WifiOff,
  TrendingUp,
  AlertTriangle,
  ShieldAlert,
  ArrowLeft,
  Check
} from "lucide-react";
import { FileUpload } from "@/src/components/FileUpload";
import { MappingView } from "@/src/components/MappingView";
import { ResultsView } from "@/src/components/ResultsView";
import { SettingsView } from "@/src/components/SettingsView";
import { HistoryView } from "@/src/components/HistoryView";
import { Dataset, ReconciliationResult, ReconciliationSettings } from "@/src/types";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Toaster } from "@/components/ui/sonner";
import { toast } from "sonner";
import { motion, AnimatePresence } from "motion/react";
import { 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  Tooltip, 
  ResponsiveContainer, 
  PieChart, 
  Pie, 
  Cell, 
  Legend 
} from "recharts";

import { useAuth } from "@/src/components/FirebaseProvider";
import { doc, updateDoc, collection, query, where, onSnapshot } from "firebase/firestore";
import { db } from "@/src/lib/firebase";
import { LogIn, CreditCard, Sparkles, LogOut, BookOpen } from "lucide-react";
import { UserGuide } from "@/src/components/UserGuide";
import { ChatBot } from "@/src/components/ChatBot";
import { ReportsDashboard } from "@/src/components/ReportsDashboard";

type AppStep = "upload" | "mapping" | "results" | "reports" | "history" | "settings" | "guide";

export default function App() {
  const { user, profile, loading, login, logout, isSubscribed } = useAuth();
  const [step, setStep] = useState<AppStep>("upload");
  const [datasetA, setDatasetA] = useState<Dataset | null>(null);
  const [datasetB, setDatasetB] = useState<Dataset | null>(null);
  const [result, setResult] = useState<ReconciliationResult | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [serverStatus, setServerStatus] = useState<"checking" | "online" | "offline">("checking");
  const [lastInstanceId, setLastInstanceId] = useState<string | null>(null);
  const [settings, setSettings] = useState<ReconciliationSettings>({
    amountTolerance: 1.0,
    dateTolerance: 2,
    nameSimilarityThreshold: 0.85,
    algorithm: "exact",
    autoArchive: true,
    notifications: true
  });

  const [settingsTab, setSettingsTab] = useState("matching");
  const [pendingAccessCount, setPendingAccessCount] = useState(0);
  const [pendingPaymentCount, setPendingPaymentCount] = useState(0);

  useEffect(() => {
    if (profile?.role !== 'admin') {
      setPendingAccessCount(0);
      setPendingPaymentCount(0);
      return;
    }

    // Listener for pending access requests
    const usersQuery = query(collection(db, "users"), where("accessStatus", "==", "pending"));
    const unsubscribeUsers = onSnapshot(usersQuery, (snapshot) => {
      setPendingAccessCount(snapshot.size);
    }, (error) => {
      console.error("Error listening to pending users:", error);
    });

    // Listener for pending payment requests
    const paymentsQuery = query(collection(db, "payment_requests"), where("status", "==", "pending"));
    const unsubscribePayments = onSnapshot(paymentsQuery, (snapshot) => {
      setPendingPaymentCount(snapshot.size);
    }, (error) => {
      console.error("Error listening to pending payments:", error);
    });

    return () => {
      unsubscribeUsers();
      unsubscribePayments();
    };
  }, [profile?.role]);

  useEffect(() => {
    let retryCount = 0;
    const maxRetries = 15; // 30 seconds total at 2s interval

    const checkServer = async () => {
      try {
        console.log("Pinging server...");
        const res = await fetch("/api/ping", { cache: 'no-store' });
        if (res.ok) {
          const data = await res.json();
          if (data.pong) {
            console.log("Server online");
            setServerStatus("online");
            retryCount = 0; 
            
            if (data.instanceId) {
              setLastInstanceId(prev => {
                if (prev && prev !== data.instanceId) {
                  setDatasetA(null);
                  setDatasetB(null);
                  if (step === "mapping" || step === "results") {
                    setStep("upload");
                    toast.info("Backend restarted. State synchronized.");
                  }
                }
                return data.instanceId;
              });
            }
          }
        } else {
          throw new Error(`Status ${res.status}`);
        }
      } catch (err) {
        console.warn("Ping attempt failed:", err);
        if (retryCount >= maxRetries) {
          setServerStatus("offline");
        } else {
          retryCount++;
          setTimeout(checkServer, 2000);
        }
      }
    };

    checkServer();
    const interval = setInterval(checkServer, 45000); // Check every 45s
    return () => clearInterval(interval);
  }, []);

  const handleRunReconciliation = async (mapA: any, mapB: any) => {
    if (!isSubscribed) {
      toast.error("Subscription required to run reconciliation");
      setStep("settings");
      return;
    }
    if (!datasetA || !datasetB) return;
    
    setIsProcessing(true);
    try {
      const response = await fetch("/api/reconcile", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          sourceAId: datasetA.id,
          sourceBId: datasetB.id,
          mappingA: mapA,
          mappingB: mapB,
          rules: { 
            amountTolerance: settings.amountTolerance, 
            dateTolerance: settings.dateTolerance,
            nameSimilarityThreshold: settings.nameSimilarityThreshold,
            algorithm: settings.algorithm
          }
        }),
      });
      
      const data = await response.json();
      
      if (!response.ok) {
        if (data.error === "Datasets not found") {
          setDatasetA(null);
          setDatasetB(null);
          setStep("upload");
          throw new Error("Server session expired or restarted. Please re-upload your datasets.");
        }
        throw new Error(data.error || "Reconciliation failed");
      }

      setResult(data);
      setStep("results");
      
      // Increment reconciliation count in profile
      if (user) {
        const userRef = doc(db, "users", user.uid);
        updateDoc(userRef, {
          reconciliationCount: (profile?.reconciliationCount || 0) + 1
        }).catch(err => console.error("Failed to update recon count:", err));
      }

      toast.success("Reconciliation completed successfully!");
    } catch (error) {
      console.error("Reconciliation error:", error);
      toast.error(error instanceof Error ? error.message : "Reconciliation failed. Please check your mappings.");
    } finally {
      setIsProcessing(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-[#F8F9FB] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-600 border-t-transparent rounded-full animate-spin" />
          <p className="text-gray-500 font-medium">Initializing SmartRecon...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-[#F8F9FB] flex flex-col items-center justify-center p-4 space-y-12 py-20">
        <Card className="max-w-md w-full p-8 text-center space-y-6 shadow-xl border-none">
          <div className="flex justify-center">
            <div className="w-16 h-16 bg-blue-600 rounded-2xl flex items-center justify-center shadow-lg shadow-blue-200">
              <ShieldCheck className="w-10 h-10 text-white" />
            </div>
          </div>
          <div className="space-y-2">
            <h1 className="text-3xl font-bold tracking-tight text-gray-900">SmartRecon</h1>
            <p className="text-gray-500">Enterprise-grade financial reconciliation at your fingertips.</p>
          </div>
          <div className="pt-4">
            <Button onClick={login} className="w-full h-12 text-lg bg-blue-600 hover:bg-blue-700 gap-3">
              <LogIn className="w-5 h-5" />
              Sign in with Google
            </Button>
          </div>
          <p className="text-xs text-gray-400">
            By signing in, you agree to our Terms of Service and Privacy Policy.
          </p>
        </Card>
        
        {/* Features Comparison */}
        <div className="max-w-4xl w-full grid grid-cols-1 md:grid-cols-2 gap-8">
          <Card className="p-8 border-none shadow-lg bg-white space-y-6">
            <div className="space-y-2">
              <h3 className="text-xl font-bold">Free Tier</h3>
              <p className="text-gray-500 text-sm">Perfect for testing and small datasets.</p>
            </div>
            <div className="text-3xl font-bold">0 ETB <span className="text-sm font-normal text-gray-400">/ month</span></div>
            <ul className="space-y-3">
              {["Basic reconciliation", "Manual mapping", "Limited history", "Standard support"].map((f, i) => (
                <li key={i} className="flex items-center gap-2 text-sm text-gray-600">
                  <div className="w-4 h-4 rounded-full bg-gray-100 flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 text-gray-400" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
            <Button variant="outline" className="w-full" onClick={login}>Get Started</Button>
          </Card>

          <Card className="p-8 border-none shadow-xl bg-gradient-to-br from-blue-600 to-blue-700 text-white space-y-6 relative overflow-hidden">
            <div className="absolute top-4 right-4">
              <Badge className="bg-white/20 text-white border-none backdrop-blur-sm">Popular</Badge>
            </div>
            <div className="space-y-2">
              <h3 className="text-xl font-bold">SmartRecon Pro</h3>
              <p className="text-blue-100 text-sm">Full automation for enterprise finance.</p>
            </div>
            <div className="text-3xl font-bold">500 ETB <span className="text-sm font-normal text-blue-200">/ month</span></div>
            <ul className="space-y-3">
              {["Unlimited batches", "AI-powered mapping", "Full audit history", "Priority support", "Anomaly detection"].map((f, i) => (
                <li key={i} className="flex items-center gap-2 text-sm text-blue-50">
                  <div className="w-4 h-4 rounded-full bg-white/20 flex items-center justify-center shrink-0">
                    <Check className="w-2.5 h-2.5 text-white/40" />
                  </div>
                  {f}
                </li>
              ))}
            </ul>
            <Button variant="secondary" className="w-full bg-white text-blue-600 hover:bg-blue-50" onClick={login}>Contact Sales</Button>
          </Card>
        </div>
      </div>
    );
  }

  if (profile?.accessStatus === 'pending') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md w-full">
          <Card className="p-8 text-center border-none shadow-2xl shadow-blue-100">
            <div className="space-y-6">
              <div className="w-20 h-20 bg-amber-50 rounded-full flex items-center justify-center mx-auto">
                <ShieldAlert className="w-10 h-10 text-amber-500" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-gray-900">Access Request Pending</h2>
                <p className="text-gray-500 text-sm">Your account is currently in the verification queue. Our administrators will review your request shortly.</p>
              </div>
              <Button variant="outline" onClick={logout} className="w-full">Sign Out</Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  if (profile?.accessStatus === 'blocked') {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center p-6">
        <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} className="max-w-md w-full">
          <Card className="p-8 text-center border-none shadow-2xl shadow-red-100">
            <div className="space-y-6">
              <div className="w-20 h-20 bg-red-50 rounded-full flex items-center justify-center mx-auto">
                <ShieldAlert className="w-10 h-10 text-red-500" />
              </div>
              <div className="space-y-2">
                <h2 className="text-2xl font-bold text-gray-900">Access Restricted</h2>
                <p className="text-gray-500 text-sm">Your access to this platform has been restricted by the administrator. Please contact support if you believe this is an error.</p>
              </div>
              <Button variant="outline" onClick={logout} className="w-full">Sign Out</Button>
            </div>
          </Card>
        </motion.div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F8F9FB] flex">
      {/* Sidebar */}
      <aside className="w-64 bg-[#1A1D21] text-white flex flex-col hidden md:flex">
        <div className="p-6 flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
            <ShieldCheck className="w-5 h-5" />
          </div>
          <h1 className="text-xl font-bold tracking-tight">SmartRecon</h1>
        </div>
        
        <nav className="flex-1 px-4 space-y-1 mt-4">
          <NavItem 
            icon={<LayoutDashboard className="w-4 h-4" />} 
            label="Dashboard" 
            active={step === "results"} 
            onClick={() => result ? setStep("results") : toast.info("Run a reconciliation to see the dashboard")}
          />
          {profile?.role === 'admin' && (
            <NavItem 
              icon={<ShieldCheck className="w-4 h-4" />} 
              label="Access" 
              active={step === "settings" && settingsTab === "permissions"}
              badge={pendingAccessCount + pendingPaymentCount}
              onClick={() => {
                setSettingsTab("permissions");
                setStep("settings");
              }}
            />
          )}
          <NavItem 
            icon={<FileUp className="w-4 h-4" />} 
            label="Reconcile" 
            active={step === "upload" || step === "mapping"} 
            onClick={() => setStep("upload")}
          />
          <NavItem 
            icon={<BarChart3 className="w-4 h-4" />} 
            label="Reports" 
            active={step === "reports"}
            onClick={() => setStep("reports")}
          />
          <NavItem 
            icon={<ArrowRightLeft className="w-4 h-4" />} 
            label="History" 
            active={step === "history"}
            onClick={() => setStep("history")}
          />
          <NavItem 
            icon={<BookOpen className="w-4 h-4" />} 
            label="Learning Center" 
            active={step === "guide"}
            onClick={() => setStep("guide")}
          />
        </nav>

        <div className="p-4 mt-auto border-t border-gray-800">
          <NavItem 
            icon={<Settings className="w-4 h-4" />} 
            label="Settings" 
            active={step === "settings"}
            onClick={() => {
              setSettingsTab("matching");
              setStep("settings");
            }}
          />
          <div className="mt-4 flex flex-col gap-2">
            <div 
              className="flex items-center gap-3 px-2 py-3 rounded-lg hover:bg-gray-800 cursor-pointer transition-colors"
              onClick={() => {
                setSettingsTab("matching");
                setStep("settings");
              }}
            >
              <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
                <User className="w-4 h-4" />
              </div>
              <div className="flex-1 overflow-hidden">
                <p className="text-xs font-medium truncate">{profile?.displayName || 'Finance Admin'}</p>
                <p className="text-[10px] text-gray-400 truncate">{profile?.email}</p>
              </div>
            </div>
            <Button 
              variant="ghost" 
              size="sm" 
              className="w-full justify-start gap-3 text-gray-400 hover:text-white hover:bg-gray-800"
              onClick={logout}
            >
              <LogOut className="w-4 h-4" />
              Log Out
            </Button>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-white border-b flex items-center justify-between px-8">
          <div className="flex items-center gap-4 flex-1">
            <div className="relative w-64">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
              <input 
                type="text" 
                placeholder="Search transactions..." 
                className="w-full pl-10 pr-4 py-1.5 bg-gray-100 border-none rounded-md text-sm focus:ring-2 focus:ring-blue-500 outline-none"
              />
            </div>
            
            <div className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-gray-50 border">
              {serverStatus === "checking" && <div className="w-2 h-2 rounded-full bg-yellow-400 animate-pulse" />}
              {serverStatus === "online" && <div className="w-2 h-2 rounded-full bg-green-500" />}
              {serverStatus === "offline" && <div className="w-2 h-2 rounded-full bg-red-500" />}
              <span className="text-[10px] font-medium text-gray-600 uppercase tracking-wider">
                System {serverStatus}
              </span>
              {serverStatus === "offline" && (
                <button 
                  onClick={() => window.location.reload()}
                  className="ml-2 text-[10px] text-blue-600 hover:underline font-bold"
                >
                  RECONNECT
                </button>
              )}
            </div>
          </div>
          <div className="flex items-center gap-4">
            <Button variant="ghost" size="icon" className="relative">
              <Bell className="w-5 h-5 text-gray-600" />
              <span className="absolute top-2 right-2 w-2 h-2 bg-red-500 rounded-full border-2 border-white"></span>
            </Button>
            <div className="h-8 w-px bg-gray-200"></div>
            <Button className="bg-blue-600 hover:bg-blue-700">
              New Batch
            </Button>
          </div>
        </header>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto p-8">
          <div className="max-w-5xl mx-auto">
            <AnimatePresence mode="wait">
              {!isSubscribed && step !== "settings" && (
                <motion.div
                  key="subscription-prompt"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="max-w-2xl mx-auto"
                >
                  <Card className="p-8 border-none shadow-2xl bg-white text-center space-y-8">
                    <div className="flex justify-center">
                      <div className="w-20 h-20 bg-blue-50 rounded-full flex items-center justify-center">
                        <Sparkles className="w-10 h-10 text-blue-600" />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <h2 className="text-3xl font-bold text-gray-900">Unlock SmartRecon Pro</h2>
                      <p className="text-gray-500">Your account is currently on the Free Tier. Upgrade to access automated reconciliation and AI mapping.</p>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-left">
                      {[
                        "Unlimited Batch Processing",
                        "AI-Powered Field Mapping",
                        "Full Audit Trail History",
                        "Priority Email Support"
                      ].map((f, i) => (
                        <div key={i} className="flex items-center gap-2 text-sm text-gray-600">
                          <Check className="w-4 h-4 text-green-500" />
                          {f}
                        </div>
                      ))}
                    </div>

                    <div className="pt-4 space-y-4">
                      <div className="text-3xl font-bold">500 ETB <span className="text-sm font-normal text-gray-400">/ month</span></div>
                      <Button 
                        size="lg" 
                        className="w-full bg-blue-600 hover:bg-blue-700 h-14 text-lg font-bold"
                        onClick={() => {
                          setSettingsTab("subscription");
                          setStep("settings");
                        }}
                      >
                        Upgrade via Telebirr / CBE
                      </Button>
                      <p className="text-xs text-gray-400">Instant activation after payment confirmation.</p>
                    </div>
                  </Card>
                </motion.div>
              )}

              {isSubscribed && step === "upload" && (
                <motion.div 
                  key="upload"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  className="space-y-8"
                >
                  <div className="space-y-2">
                    <h2 className="text-2xl font-bold text-gray-900">Start New Reconciliation</h2>
                    <p className="text-gray-500">Upload your data sources to begin the automated matching process.</p>
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <FileUpload label="Core Banking System (Source A)" onUpload={setDatasetA} />
                    <FileUpload label="MFI Reports (Source B)" onUpload={setDatasetB} />
                  </div>

                  <div className="flex justify-center pt-8">
                    <Button 
                      size="lg" 
                      disabled={!datasetA || !datasetB} 
                      onClick={() => setStep("mapping")}
                      className="px-12 bg-blue-600 hover:bg-blue-700"
                    >
                      Next: Matching Parameter
                    </Button>
                  </div>
                </motion.div>
              )}

              {step === "mapping" && datasetA && datasetB && (
                <motion.div 
                  key="mapping"
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  exit={{ opacity: 0, x: -20 }}
                >
                  <MappingView 
                    datasetA={datasetA} 
                    datasetB={datasetB} 
                    onMappingComplete={handleRunReconciliation} 
                  />
                </motion.div>
              )}

              {step === "results" && result && datasetA && datasetB && (
                <motion.div 
                  key="results"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                >
                  <ResultsView 
                    result={result} 
                    settings={settings}
                    datasetAName={datasetA.name}
                    datasetBName={datasetB.name}
                    onReset={() => setStep("upload")} 
                  />
                </motion.div>
              )}

              {step === "reports" && (
                <ReportsDashboard onBack={() => setStep("upload")} />
              )}

              {step === "history" && (
                <motion.div 
                  key="history"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full"
                >
                  <HistoryView />
                </motion.div>
              )}

              {step === "settings" && (
                <motion.div 
                  key="settings"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full"
                >
                  <SettingsView 
                    settings={settings} 
                    onSave={(newSettings) => {
                      setSettings(newSettings);
                      setStep("upload");
                    }} 
                    defaultTab={settingsTab}
                  />
                </motion.div>
              )}

              {step === "guide" && (
                <motion.div 
                  key="guide"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="w-full"
                >
                  <UserGuide />
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </main>
      <ChatBot />
      <Toaster position="top-right" />
    </div>
  );
}

function NavItem({ icon, label, active = false, onClick, badge = 0 }: { icon: React.ReactNode, label: string, active?: boolean, onClick?: () => void, badge?: number }) {
  return (
    <div 
      onClick={onClick}
      className={`
        flex items-center gap-3 px-3 py-2 rounded-lg cursor-pointer transition-all group relative
        ${active ? 'bg-blue-600 text-white shadow-lg shadow-blue-900/20' : 'text-gray-400 hover:bg-gray-800 hover:text-white'}
      `}
    >
      {icon}
      <span className="text-sm font-medium flex-1">{label}</span>
      {badge > 0 && (
        <span className={`
          px-1.5 py-0.5 rounded-full text-[10px] font-bold min-w-[18px] text-center
          ${active ? 'bg-white text-blue-600' : 'bg-blue-600 text-white'}
        `}>
          {badge}
        </span>
      )}
    </div>
  );
}
