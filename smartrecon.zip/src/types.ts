export interface HistoryItem {
  id: string;
  timestamp: string;
  summary: ReconciliationSummary;
  settings: ReconciliationSettings;
  datasetAName: string;
  datasetBName: string;
}

export interface ReconciliationSettings {
  amountTolerance: number;
  dateTolerance: number;
  nameSimilarityThreshold: number;
  algorithm: "exact";
  autoArchive: boolean;
  notifications: boolean;
}

export interface ReconciliationSummary {
  totalA: number;
  totalB: number;
  matched: number;
  mismatches: number;
  unmatchedA: number;
  unmatchedB: number;
  anomaliesA: number;
  anomaliesB: number;
  matchedPercent: string;
  variance: string;
}

export interface Anomaly {
  record: any;
  reasons: string[];
  severity: "low" | "medium" | "high";
}

export interface ReconciliationResult {
  summary: ReconciliationSummary;
  matched: any[];
  unmatchedA: any[];
  unmatchedB: any[];
  mismatches: any[];
  anomaliesA: Anomaly[];
  anomaliesB: Anomaly[];
}

export interface Dataset {
  id: string;
  name: string;
  headers: string[];
  preview: any[];
}
